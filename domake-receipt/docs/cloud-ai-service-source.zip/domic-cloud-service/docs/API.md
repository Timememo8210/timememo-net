# Cloud workspace API contract

Same-origin UI at /workspace/ and /admin/. English default, language stored as preference only. No account registration or login this round. Admin uses independent management access code; property visitors use a private capability link. Never store product records locally as source of truth.

All API paths start `/api/cloud`. Send `Authorization: Bearer <token>`; use sessionStorage for the access code only. Owner links `/workspace/?property=<uuid>#access=<token>`; consume fragment then remove it using history.replaceState. Buyer link same shape; determine rights only from server response, never URL role. Admin code input is password field, clear it on successful unlock; never render it in screenshots. All requests return JSON except original downloads, with errors `{error:{code,message?}}`.

## Shared
- GET /status public -> `{service,storage_ready,default_model,max_file_bytes:6291456}`.
- POST /admin/session admin code -> `{role:'admin'}`.
- GET /properties admin -> `{properties:[{id,passport_id,name,address,owner_label,created_at,record_count,document_count}]}`.
- POST /properties admin JSON `{name,address,owner_label,request_id:<randomUUID>}` -> `{property,access_url}`. Show newly issued owner link once, with copy action. Do not put links/tokens in a public list.
- GET /properties/:id scoped token or admin -> `{property,role:'admin'|'owner'|'contributor'|'buyer',records:[{id,document_id,version,status,fields,updated_at}],documents:[{id,name,mime_type,size_bytes,state,created_at,last_error,record_id}],access:[{id,role,label,revoked_at,created_at}]}`. Buyer receives only confirmed history and empty documents/access arrays. `fields` follows existing stored-record schema 1.2; buyer fields are a restricted subset; do not assume all fields exist. Dates sort by actual service date; unknown dates listed separately/last. Estimates labelled and not counted as actual completed work.
- POST /properties/:id/access owner/admin JSON `{role:'buyer'|'contributor'|'owner',label}` -> `{id,access_url,role}`. Only admin can issue owner. Owner/admin can revoke with POST /properties/:id/access/:accessId/revoke. Owner cannot revoke/issue another owner key.
- PATCH /properties/:id admin `{name,address,owner_label}` -> `{property}`; ID remains unchanged. Owner label is display only, not legal ownership verification.

## Upload, read, review, save
- POST /properties/:id/documents multipart `{file,uploader_label}` owner/contributor/admin -> `{document}`. Persist original first. `409 duplicate_document` means already uploaded to this property. 6MiB JPG/PNG/WebP/PDF. Require selected property before upload.
- POST /documents/:id/extract JSON `{locale:'en-GB'}` -> `{document,draft,outcome,model,base_version,record_id}`. `draft` schema1.2 record. Outcomes review/partial/unreadable/unrelated. Failed reading leaves the original in cloud, error visible; provide retry and manual entry. Do not automatically save record.
- GET /documents/:id owner/admin -> `{document,draft,record}` for admin compare/open existing. Contributor may read metadata/draft for review but cannot fetch stored original.
- GET /documents/:id/original owner/admin -> binary with correct content type. Use authenticated fetch then Blob URL for image/PDF preview or download. Buyer/contributor denied. Never expose unauthenticated file URLs.
- POST /properties/:id/records owner/contributor/admin JSON `{document_id,fields:<schema1.2>,confirm:true|false,base_version:<existing version or 0>}` -> `{record}`. `confirm:false` saves draft; `true` requires explicit review checkbox. Property/actor/original IDs, confirmation metadata are enforced server-side. Conflict `409 version_conflict` requires reload; never overwrite automatically. Existing same-document record updates, no duplicate.
- GET /records/:id/history owner/admin -> `{versions:[{version,fields,actor_label,created_at}]}`. Older manual corrections remain in audit. Buyer no revision history.
- GET /properties/:id/export owner/admin -> `{schema_version:'1.2',storage_scope:'cloud',property,records}`. Download as JSON. Buyer cannot export full record fields.

## Admin
- GET /admin/documents -> `{documents:[{id,property_id,property_name,name,mime_type,state,created_at,last_error,record_id}]}`. Admin overview filters client-side within returned page; show original vs record compare via document endpoints. No secret values.
- GET /admin/settings -> `{active:{id,provider,endpoint,model,has_key,key_hint,source},draft:null|{id,provider,endpoint,model,has_key,key_hint,tested_at,test_ok,pdf_supported},providers:[{id,label,endpoint}],limits:{daily_calls,max_file_bytes}}`.
- PUT /admin/settings JSON `{provider:'openrouter'|'openai-compatible',endpoint,model,api_key:<optional new key>}` -> `{draft}`. Empty key means keep key ONLY if same endpoint/provider; never send stored key to a changed host. Settings save does not activate.
- POST /admin/settings/test JSON `{config_id}` -> `{ok,model,elapsed_ms,message,tested_at,pdf_supported}`. Runs a fixed synthetic receipt IMAGE through the exact extraction contract, small charge; independent PDF capability test only for OpenRouter. Unverified generic compatible providers support images only. Show result; do not claim test means every receipt is accurate.
- POST /admin/settings/activate JSON `{config_id}` -> `{active}` only after successful test of same immutable draft. Show configured model and endpoint, API key only masked. No automatic failover on errors.
- GET /admin/activity -> `{events:[{action,property_id,actor_label,created_at,details}],usage:{calls,total_cost}}`. No key or access-token values.

Admin access code is separate from old receipt AI pilot code. User-facing page mentions original retained in cloud and accessible to property owners/admin; buyers see only shared history. Existing Domic identity integration remains next phase, but data/permissions are server-enforced now.

## Implemented refinements (2026-09-12)

- Contributor access is restricted to documents uploaded using that same contributor grant, including editing. Owner/admin manage all submissions for the property.
- `POST /documents/:id/extract` accepts `request_id`. The UI creates a fresh UUID for an explicit new reading. Replaying the same request ID returns the stored attempt result without another model call. A failed attempt is also retained; an explicit retry uses a new ID.
- Normalized uncertain classification is returned as `outcome:partial`, retaining `draft.extraction.status:uncertain`; `no_text` maps to `outcome:unreadable`. Server normalization determines the result shown, rather than raw model confidence.
- Exact schema 1.2 is retained for stored full records. `account:null` until Domic identity integration; source metadata contains only the schema fields. Cloud document ID and optimistic version are on the record wrapper; actor attribution is in revision history. Buyer history is a smaller projection, not a full schema export.
- Model testing makes one synthetic image request with GBP 264 expected. Native PDF is enabled only for the previously verified default OpenRouter Gemini model. Generic OpenAI-compatible providers and unverified model choices are images only.
- Redirects are requested in manual mode and rejected on 3xx, so a saved key is never forwarded to a redirect destination.
- General activity audit is best effort with sanitized operator warnings. Critical record revisions are transactional with the record mutation.

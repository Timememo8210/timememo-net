# Domic Home Passport — cloud workspace

A property-centred receipt archive and real multimodal extraction service. English is the default interface; Chinese is available. Production: https://domic-home-passport-ai.bobomail2000.chatgpt.site . Frontend entry: `/workspace/`; platform management: `/admin/`.

## Current scope

- Immutable property UUID and readable DHP reference. Displayed name, address and owner label may change without moving history. This is an application archive identity, not title or authenticity certification.
- D1 persists properties, hashed property access grants, document metadata, extraction attempts, proposals, versioned records, encrypted AI configurations and usage. R2 retains original PDF/JPG/PNG/WebP bytes privately (6 MiB per file). Download uses authenticated server requests; no public object URLs.
- No Domic account sign-in in this iteration. Owner/contributor/buyer links carry a 256-bit capability in a URL fragment; UI removes the fragment and keeps the token in tab session storage. Anyone holding the link has its permission until revoked. Labels are unverified display text. Owner can see their home's originals; buyer only confirmed, minimized history. Contributors can manage only their own submissions. An independent server admin code manages all homes and AI settings.
- Original first, extraction second, editable proposal third, explicit confirmation last. Empty/irrelevant results never automatically create records. Missing facts stay null/unknown. Manual correction retains immutable original and an atomic record revision. Concurrent saves reject stale versions.
- Record fields retain schema 1.2 (`docs/receipt.schema.json`). No account identity is fabricated: `account:null`. Cloud wrappers carry document_id/version/status; actor information is stored separately in revisions and audit. Buyer projection is a deliberately smaller view, not a full schema 1.2 export.
- API settings use save draft → synthetic image test → activate. Existing environment OpenRouter secret is reused without exposing it. New keys are AES-GCM encrypted under a server secret and endpoint-bound; changed endpoints require new keys. HTTPS host allowlist and redirect rejection prevent arbitrary credential forwarding. Generic OpenAI-compatible providers are images only. Native PDF is enabled for the previously verified default OpenRouter `google/gemini-3.1-flash-lite`; other models require separate PDF verification.
- Daily AI attempt limit defaults to 100 globally, includes failed attempts, enforced in D1. Upstream timeout 35 seconds. Cancellation is propagated when the platform supplies its signal; already consumed upstream work cannot be refunded by cancellation. Exact request_id replay returns a stored result; an explicit new extraction uses a fresh ID. No automatic provider fallback or silent second paid call.
- Record version writes are transactional. General activity audit is best effort; an audit failure logs a sanitized warning and does not misreport an already saved record as failed. Usage cost is reported only when upstream returns it, so missing cost is not proof of a free request.

## Development and validation

`npm ci`, `npm test`, `npm run dev`. Local preview uses fictional keys, in-memory SQLite/R2 adapters and a mocked provider; it never uses the production key. State resets when preview restarts. Production uses the actual cloud bindings. `npm run build` generates a Worker bundle containing public UI assets and migrations. Generated assets and output are ignored by Git.

Tests cover server permission boundaries, originals, schema validation, explicit confirmation, lost-update prevention, duplicate upload cleanup, request replay, normalized failure paths, rate limits, encrypted settings and frontend state transitions. The browser automation connection was unavailable during this round; DOM tests and direct cloud API acceptance are recorded separately from real browser screenshots. Prior prototype screenshots remain historical evidence for that version only.

## Runtime configuration

Set secret `OPENROUTER_API_KEY`, independent secret `DOMIC_ADMIN_TOKEN` (32 random bytes), and secret `DOMIC_SETTINGS_KEY` (base64 32 bytes, preserve it while encrypted configurations exist). Nonsecret `DOMIC_MODEL`, `DOMIC_DAILY_AI_CALLS`, `DOMIC_ALLOWED_ORIGINS`; optional server-managed `DOMIC_AI_ALLOWED_HOSTS`. Never place keys in the frontend, Git, URL query, hosting manifest or source archive. Existing `/api/health`, `/api/session`, `/api/extract` remain a separate historical pilot client interface using the old pilot code; dashboard settings and D1/R2 apply to `/api/cloud/*` and the new workspace.

## Domic integration follow-up

Replace capability authorization with verified Domic sessions and explicit property membership; preserve property/record/document IDs. Define owner transfer verification, buyer consent and redaction policy, retention/deletion requests, disaster recovery/export/backups, per-tenant budgets, abuse protection and operator key recovery before broad public rollout. This pilot does not implement legal ownership verification, immutable third-party notarization, full accounts, or property-data search across all customers.

import legacy from './legacy.js';
import {createWorkspace} from './cloud/router.js';
import {assets,testImage} from './assets.generated.js';
export * from './legacy.js';
export default createWorkspace({legacyService:legacy,assets,testImage});

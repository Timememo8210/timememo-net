import {readFile,readdir,writeFile} from 'node:fs/promises';
const assets={};
for(const name of await readdir('public')){if(!/\.(html|js|css)$/.test(name))continue;const type=name.endsWith('.html')?'text/html; charset=utf-8':name.endsWith('.js')?'text/javascript; charset=utf-8':'text/css; charset=utf-8';assets[name.endsWith('.html')?'/'+name:'/assets/'+name]={type,body:await readFile('public/'+name,'utf8')};}
const png=(await readFile('public/test-receipt.png')).toString('base64');
await writeFile('assets.generated.js','export const assets='+JSON.stringify(assets)+';\nexport const testImage=Uint8Array.from(atob('+JSON.stringify(png)+'),c=>c.charCodeAt(0));\n');

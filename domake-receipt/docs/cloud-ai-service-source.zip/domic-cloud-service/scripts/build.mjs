import {mkdir,copyFile,readdir,readFile,cp,rm} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
await import('./assets.mjs');
await rm('dist',{recursive:true,force:true});
await mkdir('dist/server',{recursive:true});await mkdir('dist/.openai',{recursive:true});
for(const name of ['worker.js','legacy.js','assets.generated.js']){execFileSync(process.execPath,['--check',name]);await copyFile(name,'dist/server/'+(name==='worker.js'?'index.js':name));}
for(const dir of ['shared','cloud']){for(const name of await readdir(dir))if(name.endsWith('.js'))execFileSync(process.execPath,['--check',dir+'/'+name]);await cp(dir,'dist/server/'+dir,{recursive:true});}
const config=JSON.parse(await readFile('.openai/hosting.json','utf8'));if(!config.project_id)throw Error('Missing Site');
await copyFile('.openai/hosting.json','dist/.openai/hosting.json');await cp('drizzle','dist/.openai/drizzle',{recursive:true});
console.log('Worker, interface assets, and database migrations prepared. No secrets bundled.');

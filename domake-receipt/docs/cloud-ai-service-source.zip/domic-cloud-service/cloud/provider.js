import { buildModelRequest, providerSchema, matchesSchema, readBounded, DEFAULT_MODEL } from '../legacy.js';
import { normalizeAIExtraction } from '../shared/ai-contract.js';
import { AppError, first, rows, run, stmt, db, iso, uid, encrypt, decrypt, text, audit } from './common.js';

export const PROVIDERS=[{id:'openrouter',label:'OpenRouter (images and native PDF)',endpoint:'https://openrouter.ai/api/v1/chat/completions'},{id:'openai-compatible',label:'OpenAI-compatible (tested images only)',endpoint:'https://api.openai.com/v1/chat/completions'}];
const HOSTS=new Set(['openrouter.ai','api.openai.com','generativelanguage.googleapis.com','api.groq.com','api.mistral.ai','api.together.xyz','api.deepinfra.com','api.fireworks.ai','api.x.ai']);
export function validateEndpoint(provider,value,env={}){
 if(!PROVIDERS.some(p=>p.id===provider))throw new AppError('unsupported_provider');
 let u;try{u=new URL(value);}catch{throw new AppError('invalid_endpoint');}
 const allowed=new Set([...HOSTS,...(env.DOMIC_AI_ALLOWED_HOSTS||'').split(',').map(x=>x.trim().toLowerCase()).filter(Boolean)]);
 if(u.protocol!=='https:'||u.username||u.password||u.search||u.hash||u.port||!allowed.has(u.hostname)||!u.pathname.endsWith('/chat/completions'))throw new AppError('endpoint_not_allowed',400,'Use a supported HTTPS chat/completions endpoint.');
 if(provider==='openrouter'&&u.href!==PROVIDERS[0].endpoint)throw new AppError('invalid_endpoint');
 return u.href;
}
export function configView(c){if(!c)return null;return {id:c.id,provider:c.provider,endpoint:c.endpoint,model:c.model,has_key:!!(c.key_cipher||c.key),key_hint:c.key_hint||'Server secret configured',tested_at:c.tested_at||null,test_ok:!!c.test_ok,pdf_supported:!!c.pdf_supported,source:c.source||'dashboard',test_message:c.test_message||null};}
export async function activeConfig(env){
 const s=await first(env,"SELECT value FROM settings WHERE key='active_ai_config'");
 if(s){const c=await first(env,'SELECT * FROM ai_configs WHERE id=?',s.value);if(!c)throw new AppError('settings_unavailable',503);return c;}
 if(!env.OPENROUTER_API_KEY)throw new AppError('not_configured',503);
 return {id:'environment',provider:'openrouter',endpoint:PROVIDERS[0].endpoint,model:env.DOMIC_MODEL||DEFAULT_MODEL,key:env.OPENROUTER_API_KEY,key_hint:'Server secret configured',test_ok:1,pdf_supported:(env.DOMIC_MODEL||DEFAULT_MODEL)===DEFAULT_MODEL,source:'environment'};
}
export async function configKey(env,c){return c.key||decrypt(env,c.key_cipher,c.id+'|'+c.endpoint);}
export async function getSettings(env){const active=await activeConfig(env);const d=await first(env,"SELECT value FROM settings WHERE key='draft_ai_config'");const draft=d?await first(env,'SELECT * FROM ai_configs WHERE id=?',d.value):null;return {active:configView(active),draft:configView(draft),providers:PROVIDERS,limits:{daily_calls:dailyLimit(env),max_file_bytes:6291456}};}
export async function saveConfig(env,who,input){
 const provider=text(input.provider,40,true), endpoint=validateEndpoint(provider,text(input.endpoint,500,true),env),model=text(input.model,150,true);
 if(!/^[A-Za-z0-9][A-Za-z0-9_./:@-]{0,149}$/.test(model))throw new AppError('invalid_model');
 let key=text(input.api_key,500);if(!key){const s=await first(env,"SELECT value FROM settings WHERE key='draft_ai_config'");const previous=s?await first(env,'SELECT * FROM ai_configs WHERE id=?',s.value):await activeConfig(env);if(previous.provider!==provider||previous.endpoint!==endpoint)throw new AppError('new_key_required',400,'Enter a new API key when changing provider or endpoint.');key=await configKey(env,previous);}
 if(key.length<12||/\s/.test(key))throw new AppError('invalid_api_key');
 const id=uid(),cipher=await encrypt(env,key,id+'|'+endpoint),hint='••••'+key.slice(-4);
 await db(env).batch([stmt(env,'INSERT INTO ai_configs (id,provider,endpoint,model,key_cipher,key_hint,created_at) VALUES (?,?,?,?,?,?,?)',id,provider,endpoint,model,cipher,hint,iso()),stmt(env,"INSERT INTO settings (key,value) VALUES ('draft_ai_config',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",id)]);
 await audit(env,who,'api.configuration_draft',null,{config_id:id,provider,endpoint,model});return {draft:configView(await first(env,'SELECT * FROM ai_configs WHERE id=?',id))};
}
const dailyLimit=env=>Math.min(1000,Math.max(1,Number(env.DOMIC_DAILY_AI_CALLS)||100));
async function reserve(env,who,c,propertyId){const id=uid(),today=iso().slice(0,10);const result=await run(env,'INSERT INTO usage_events (id,day,property_id,actor_id,config_id,model,state,created_at) SELECT ?,?,?,?,?,?,?,? WHERE (SELECT count(*) FROM usage_events WHERE day=?) < ?',id,today,propertyId||null,who.id,c.id,c.model,'pending',iso(),today,dailyLimit(env));if(!result.meta?.changes)throw new AppError('daily_limit_reached',429);return id;}
function payload(c,file,bytes,locale){
 let body;try{body=buildModelRequest(file,bytes,c.model,locale);}catch{body=buildModelRequest(file,bytes,DEFAULT_MODEL,locale);body.model=c.model;delete body.provider.max_price;}
 if(file.type==='application/pdf'&&!c.pdf_supported)throw new AppError('provider_pdf_unsupported',415,'This model has not yet been verified for PDFs. Use an image or enter details manually.');
 if(c.provider!=='openrouter'){if(file.type==='application/pdf')throw new AppError('provider_pdf_unsupported',415,'This provider has only been enabled for images.');delete body.provider;delete body.reasoning;delete body.plugins;body.response_format.json_schema.schema=providerSchema();}
 return body;
}
export async function invoke(env,who,c,file,bytes,{fetcher=fetch,locale='en-GB',propertyId=null,signal}={}){
 if(signal?.aborted)throw new AppError('cancelled',499);
 validateEndpoint(c.provider,c.endpoint,env);const body=payload(c,file,bytes,locale),key=await configKey(env,c);if(signal?.aborted)throw new AppError('cancelled',499);const usageId=await reserve(env,who,c,propertyId);const start=Date.now(),controller=new AbortController();const abort=()=>controller.abort();signal?.addEventListener('abort',abort,{once:true});if(signal?.aborted)abort();const timer=setTimeout(abort,35000);let cost=null;
 try{
  const response=await fetcher(c.endpoint,{method:'POST',redirect:'manual',headers:{Authorization:'Bearer '+key,'Content-Type':'application/json',...(c.provider==='openrouter'?{'HTTP-Referer':'https://timememo.net/domake-receipt/','X-OpenRouter-Title':'Domic Home Passport'}:{})},body:JSON.stringify(body),signal:controller.signal});
  if(response.status>=300&&response.status<400)throw new AppError('upstream_redirect_refused',502);
  if(!response.ok){console.warn(JSON.stringify({event:'ai_http_error',status:response.status}));const codes={401:'service_auth_failed',403:'service_auth_failed',402:'insufficient_credits',429:'rate_limited',404:'model_unavailable'};throw new AppError(codes[response.status]||'upstream_failed',response.status===402?402:response.status===429?429:502);}
  const raw=await readBounded(response.body,512*1024,controller.signal);let value;try{value=JSON.parse(new TextDecoder().decode(raw));}catch{throw new AppError('invalid_response',502);}
  if(Number.isFinite(value.usage?.cost)&&value.usage.cost>=0)cost=value.usage.cost;
  const choice=value.choices?.[0];if(value.error||choice?.finish_reason!=='stop'||typeof choice.message?.content!=='string')throw new AppError('invalid_response',502);
  let extraction;try{extraction=JSON.parse(choice.message.content);}catch{throw new AppError('invalid_response',502);}
  if(!matchesSchema(extraction))throw new AppError('invalid_response',502);
  const draft=normalizeAIExtraction(extraction,{model:c.model,engine:c.provider,requestId:value.id,usage:value.usage});
  await run(env,"UPDATE usage_events SET state='succeeded',cost=?,elapsed_ms=? WHERE id=?",cost,Date.now()-start,usageId);
  return {extraction,draft,model:c.model,elapsed_ms:Date.now()-start,cost};
 }catch(e){await run(env,"UPDATE usage_events SET state='failed',cost=?,elapsed_ms=? WHERE id=?",cost,Date.now()-start,usageId);if(controller.signal.aborted)throw new AppError(signal?.aborted?'cancelled':'timeout',signal?.aborted?499:504);if(e instanceof AppError)throw e;console.warn(JSON.stringify({event:'ai_runtime_error',name:e?.name||'Error',detail:/redirect/i.test(e?.message||'')?'redirect_policy_error':/Illegal invocation/i.test(e?.message||'')?'runtime_binding_error':'unclassified'}));throw new AppError('upstream_failed',502);}finally{clearTimeout(timer);signal?.removeEventListener('abort',abort);}
}
export async function testConfig(env,who,id,testImage,fetcher){
 const c=await first(env,'SELECT * FROM ai_configs WHERE id=?',text(id,80,true));if(!c)throw new AppError('not_found',404);
 if(!testImage)throw new AppError('test_fixture_unavailable',503);
 const start=Date.now();let ok=false,message='';
 try{const result=await invoke(env,who,c,{type:'image/png'},testImage,{fetcher});const d=result.draft;
  ok=!!d?.service?.summary&&d.amount.total===264&&d.amount.currency==='GBP';message=ok?'The test image returned a valid receipt draft with the expected GBP 264 total.':'The response did not preserve the test receipt facts. This configuration was not enabled.';
 }catch(e){message=e instanceof AppError?e.code:'upstream_failed';}
 const tested_at=iso(),pdf_supported=ok&&c.provider==='openrouter'&&c.model===DEFAULT_MODEL;await run(env,'UPDATE ai_configs SET test_ok=?,tested_at=?,pdf_supported=?,test_message=? WHERE id=?',ok?1:0,tested_at,pdf_supported?1:0,message,c.id);await audit(env,who,'api.configuration_test',null,{config_id:c.id,ok});return {ok,model:c.model,elapsed_ms:Date.now()-start,message,tested_at,pdf_supported};
}
export async function activate(env,who,id){const c=await first(env,'SELECT * FROM ai_configs WHERE id=?',text(id,80,true));if(!c)throw new AppError('not_found',404);if(!c.test_ok||!c.tested_at)throw new AppError('configuration_not_tested',409);await run(env,"INSERT INTO settings (key,value) VALUES ('active_ai_config',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",c.id);await audit(env,who,'api.configuration_activated',null,{config_id:c.id,provider:c.provider,endpoint:c.endpoint,model:c.model});return {active:configView(c)};}

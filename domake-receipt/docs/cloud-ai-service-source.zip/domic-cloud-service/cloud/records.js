import { blankRecord, get, set, inspect, categories, types, payments, completions, changes } from '../shared/core.js';
import { AppError, text } from './common.js';
const strings=['property.service_address','document.number','document.issue_date','service.date','service.summary','service.location','provider.name','provider.organization_name','provider.person_name','provider.phone','provider.address','amount.currency','details.asset_model','details.asset_serial','details.warranty','details.permit_number','notes'];
const enums={'document.type':types,'service.category':categories,'service.change_type':changes,'service.completion_status':completions,'amount.payment_status':payments};
const number=v=>{if(v==null||v==='')return null;if(typeof v!=='number'||!Number.isFinite(v)||v<0||v>Number.MAX_SAFE_INTEGER)throw new AppError('invalid_amount');return v;};
export function safeFields(input,{property,document,who,confirm,id,now}){
 if(!input||typeof input!=='object'||Array.isArray(input))throw new AppError('invalid_fields');
 const r=blankRecord();for(const p of strings)set(r,p,text(get(input,p),p==='service.summary'||p==='notes'?2000:1200));
 for(const [p,values]of Object.entries(enums)){const v=get(input,p)??'unknown';if(typeof v!=='string'||!Object.hasOwn(values,v))throw new AppError('invalid_category');set(r,p,v);}
 r.amount.total=number(input.amount?.total);if(input.items!=null&&!Array.isArray(input.items))throw new AppError('invalid_items');if((input.items||[]).length>50)throw new AppError('invalid_items');r.items=(input.items||[]).map(i=>({description:text(i.description,1000),amount:number(i.amount)}));
 r.provider.name ||= r.provider.organization_name||r.provider.person_name;
 r.id=id;r.property.id=property.passport_id;r.property.uid=property.id;r.account=null;
 const proposal=document.analysis_json?JSON.parse(document.analysis_json):null;
 r.source={name:document.name,mime_type:document.mime_type,sha256:document.sha256,mode:proposal?'cloud_ai':'manual'};
 r.extraction=proposal?.draft?.extraction||null;r.evidence=proposal?.draft?.evidence||[];
 const check=inspect(r,{confirm});if(check.errors.length)throw new AppError('invalid_record',422,check.errors.join(' '));
 const paths=[...strings,...Object.keys(enums),'amount.total','items'];
 r.review={status:confirm?'confirmed':'draft',missing_fields:check.missing,warnings:check.warnings,edited_fields:paths.filter(p=>JSON.stringify(get(proposal?.draft||blankRecord(),p))!==JSON.stringify(get(r,p)))};r.updated_at=now;r.confirmed_at=confirm?now:null;
 return r;
}
export function recordView(row,buyer=false){const f=JSON.parse(row.fields_json);return {id:row.id,...(!buyer?{document_id:row.document_id}:{}),version:row.version,status:row.status,updated_at:row.updated_at,fields:buyer?{schema_version:f.schema_version,property:{id:f.property.id,uid:f.property.uid},document:{type:f.document.type},service:f.service,provider:{name:f.provider.name,organization_name:f.provider.organization_name,person_name:f.provider.person_name},amount:f.amount,items:f.items,details:{asset_model:f.details.asset_model,warranty:f.details.warranty}}:f};}
export function documentView(d){return {id:d.id,property_id:d.property_id,name:d.name,mime_type:d.mime_type,size_bytes:d.size_bytes,sha256:d.sha256,state:d.state,uploader_label:d.uploader_label,last_error:d.last_error,created_at:d.created_at,updated_at:d.updated_at,record_id:d.record_id||null};}
export const propertyView=p=>({id:p.id,passport_id:p.passport_id,name:p.name,address:p.address,owner_label:p.owner_label,created_at:p.created_at,updated_at:p.updated_at,...(p.record_count!=null?{record_count:p.record_count,document_count:p.document_count}:{})});

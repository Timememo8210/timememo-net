import {$,$$,L,escape,initUI,notice,tokenGet,tokenSet,downloadJSON,copyPrivateLink,tr} from './ui.js';
import {makeAPI,errorText,APIError} from './api.js';
import {prepareFields,renderEditor,collectEditor,validationText,recordSummary,timelineHTML,renderOriginal} from './record-ui.js';
import {validateFile} from './record-core.js';

const params=new URLSearchParams(location.search), propertyId=params.get('property')||'';
const fragment=new URLSearchParams(location.hash.slice(1)), incoming=fragment.get('access');
if(location.hash)history.replaceState(null,'',location.pathname+location.search);
const propertyTokenKey='domic-property-access-'+propertyId;
if(incoming&&propertyId)tokenSet(propertyTokenKey,incoming);
let token=incoming||tokenGet(propertyTokenKey)||tokenGet('domic-cloud-admin');
const api=makeAPI(()=>token);
let propertyData=null,status=null,busy=false,readingController=null,intake=null,selectedFile=null,currentRecord=null;
let previewUrl=null,originalBlob=null,openedOriginalUrls=[];
const canWrite=()=>['owner','contributor','admin'].includes(propertyData?.role);
const canOriginal=()=>['owner','admin'].includes(propertyData?.role);
const canManageAccess=()=>['owner','admin'].includes(propertyData?.role);
const path='/properties/'+encodeURIComponent(propertyId);
$('.brand').href='/workspace/'+(propertyId?'?property='+encodeURIComponent(propertyId):'');

function requireWrite(){if(!canWrite())throw new APIError('forbidden',403);}
function hideStages(){for(const id of ['upload-stage','processing-stage','review-stage'])$('#'+id).hidden=true;}
function setStage(stage){hideStages();$('#'+stage+'-stage').hidden=false;$('#step-add').classList.toggle('active',stage==='upload');$('#step-review').classList.toggle('active',stage==='review'||stage==='processing');$('#step-confirm').classList.remove('active');}
function setBusy(value){busy=value;$('#read-document').disabled=value||!selectedFile;$('#confirm-save').disabled=value||!$('#confirm-check').checked;$('#choose-another').disabled=value;}
function releasePreview(){if(previewUrl)URL.revokeObjectURL(previewUrl);previewUrl=null;originalBlob=null;$('#intake-original').replaceChildren();}
function setPreview(blob){releasePreview();if(!blob){$('#intake-original').textContent=L('The stored original is available to property owners and administrators.','云端原件仅房屋主人和管理员可访问。');$('#open-intake-original').hidden=true;return;}originalBlob=blob;previewUrl=renderOriginal($('#intake-original'),blob);$('#open-intake-original').hidden=false;}
function unsaved(){return Boolean(intake&&!intake.saved&&(selectedFile||intake.document||intake.fields));}
function discardAllowed(){return !unsaved()||window.confirm(L('Leave these unsaved edits? Uploaded originals will remain attached to this property.','放弃尚未保存的修改吗？已上传的原件仍会保留在这栋房屋下。'));}
function closeIntake(){if(busy&&!readingController){notice('#intake-message',L('Please wait for this request to finish.','请等待当前请求完成。'));return;}if(!discardAllowed())return;if(busy)readingController?.abort();intake=null;selectedFile=null;$('#intake-dialog').close();$('#confirm-dialog').close();releasePreview();}
function freshIntake(){intake={document:null,fields:null,baseVersion:0,recordId:null,saved:false};selectedFile=null;$('#document-file').value='';$('#selected-file').hidden=true;notice('#intake-message');notice('#review-validation');notice('#confirm-message');releasePreview();$('#intake-property').textContent=propertyData.property.name+' · '+propertyData.property.address;setStage('upload');setBusy(false);}
function openNew(){if(!canWrite()||busy||!discardAllowed())return;freshIntake();$('#intake-dialog').showModal();}
function acceptFile(file){if(!file||busy)return;const error=validateFile(file);if(error){notice('#intake-message',L('Choose a valid PDF, JPG, PNG or WebP file.','请选择有效的 PDF、JPG、PNG 或 WebP 文件。'),'error');return;}if(file.size>(status?.max_file_bytes||6291456)){notice('#intake-message',errorText(new APIError('file_too_large')),'error');return;}selectedFile=file;$('#selected-file').textContent=file.name+' · '+(file.size/1024/1024).toFixed(2)+' MB';$('#selected-file').hidden=false;$('#read-document').disabled=false;notice('#intake-message');}
async function loadProperty(){
  if(!propertyId||!token)throw new APIError('access_required');
  const data=await api(path);if(!data.property||!['admin','owner','contributor','buyer'].includes(data.role))throw new APIError('invalid_response');
  propertyData=data;renderWorkspace();$('#access-state').hidden=true;$('#workspace-content').hidden=false;$('#viewer-badge').hidden=false;
}
function renderWorkspace(){if(!propertyData)return;const {property,role}=propertyData;
  $('#property-name').textContent=property.name;$('#property-address').textContent=property.address;
  $('#property-reference').textContent=property.passport_id||property.id;$('#property-role').textContent=roleLabel(role);$('#viewer-badge').textContent=roleLabel(role);
  $('#property-count').textContent='1';$('#property-list').innerHTML=`<button type="button" class="property-button" aria-current="true"><strong>${escape(property.name)}</strong><small>${escape(property.address)}</small></button>`;
  $('#property-access-note').textContent=role==='buyer'?L('Shared history only. Original documents, private access links and revision history are not available through this link.','仅共享房屋历史，此链接不提供原始单据、私有访问链接或修改历史。'):role==='contributor'?L('You can upload and confirm your own submissions. Stored originals are available only to the owner and administrators.','你可以上传并确认自己的提交记录；云端原件仅房屋主人和管理员可访问。'):L('Originals and confirmed records are retained in the cloud for this permanent property. Buyer links share the history only.','原件和已确认记录保留在云端，并关联永久房屋身份；买家链接只共享历史。');
  $('#add-document').hidden=!canWrite();
  const records=(propertyData.records||[]).filter(record=>role!=='buyer'||record.status==='confirmed');
  $('#history-count').textContent=String(records.length);$('#history-list').innerHTML=timelineHTML(records,{canEdit:canWrite(),canOriginal:canOriginal()});$('#history-empty').hidden=records.length>0;
  bindRecordButtons($('#history-list'));
  renderPendingDocuments();renderSharing();
}
function roleLabel(role){return {owner:L('Property owner','房屋主人'),admin:L('Administrator','管理员'),contributor:L('Contributor','协作者'),buyer:L('Shared history','共享历史')}[role]||role;}
function bindRecordButtons(host){host.querySelectorAll('[data-record]').forEach(button=>button.onclick=()=>openRecord(button.dataset.record));host.querySelectorAll('[data-edit]').forEach(button=>button.onclick=()=>editRecord(button.dataset.edit));host.querySelectorAll('[data-original]').forEach(button=>button.onclick=()=>openOriginal(button.dataset.original));}
function renderPendingDocuments(){
 let panel=$('#pending-documents');if(!panel){panel=document.createElement('section');panel.id='pending-documents';panel.className='panel';$('.workspace-main').append(panel);}
 panel.hidden=!canWrite();if(!canWrite()){panel.replaceChildren();return;}
 const documents=(propertyData.documents||[]).filter(doc=>!doc.record_id);
 panel.innerHTML=`<div class="panel-heading"><h2>${tr('drafts')}</h2><span class="count">${documents.length}</span></div><div class="pending-list">${documents.length?documents.map(doc=>`<article class="pending-row"><div><strong>${escape(doc.name)}</strong><p class="small muted">${escape(doc.state||'')} ${doc.last_error?' · '+escape(errorText({code:doc.last_error})):''}</p></div><button class="button secondary" data-resume="${escape(doc.id)}">${L('Open / continue','打开／继续')}</button></article>`).join(''):`<p class="small muted">${L('All uploaded documents are attached to records, or no documents have been uploaded.','暂无需要继续核对的原件。')}</p>`}</div>`;
 panel.querySelectorAll('[data-resume]').forEach(button=>button.onclick=()=>resumeDocument(button.dataset.resume));
}
function renderSharing(){
 let panel=$('#property-sharing');if(!panel){panel=document.createElement('section');panel.id='property-sharing';panel.className='panel';$('.workspace-main').append(panel);}
 panel.hidden=!canManageAccess();if(!canManageAccess()){panel.replaceChildren();return;}
 panel.innerHTML=`<div class="panel-heading"><h2>${L('Share access to this home','分享房屋访问权限')}</h2><button class="text-button" id="export-property">${L('Export property JSON','导出房屋 JSON')}</button></div><div class="sharing-content"><p class="small muted">${L('Buyer links show confirmed history without originals. Contributor links allow uploads and review of their own submissions, without access to stored originals.','买家链接可查看已确认历史，不含原件。协作者链接可上传、核对自己的记录，但不能访问已保存原件。')}</p><form id="share-access-form" class="inline-form"><label>${L('Access','权限')}<select id="share-role"><option value="buyer">${L('Buyer · history only','买家 · 仅历史')}</option><option value="contributor">${L('Contributor · upload and review','协作者 · 上传核对')}</option>${propertyData.role==='admin'?`<option value="owner">${L('Owner · originals included','房主 · 可查看原件')}</option>`:''}</select></label><label>${L('Label','备注')}<input id="share-label" maxlength="150" required></label><button class="button secondary" type="submit">${L('Create private link','创建私有链接')}</button></form><div id="new-access-result" hidden></div><div id="share-message" class="notice" role="status" hidden></div><div id="access-list">${(propertyData.access||[]).map(item=>`<div class="access-row"><span>${escape(item.label||roleLabel(item.role))} · ${escape(roleLabel(item.role))}${item.revoked_at?' · '+L('Revoked','已撤销'):''}</span>${!item.revoked_at&&(item.role!=='owner'||propertyData.role==='admin')?`<button class="text-button" data-revoke="${escape(item.id)}">${L('Revoke','撤销')}</button>`:''}</div>`).join('')}</div></div>`;
 $('#share-access-form').onsubmit=async event=>{event.preventDefault();const button=event.submitter;button.disabled=true;try{const response=await api(path+'/access',{method:'POST',json:{role:$('#share-role').value,label:$('#share-label').value.trim()}});const link=response.access_url;$('#new-access-result').hidden=false;$('#new-access-result').innerHTML=`<p class="small">${L('New private link issued. Copy it now; it will not appear in the access list.','新私有链接已创建，请现在复制；它不会出现在访问列表中。')}</p><button class="button secondary" id="copy-issued-link">${L('Copy private link','复制私有链接')}</button>`;$('#copy-issued-link').onclick=async()=>{try{await copyPrivateLink(link);notice('#share-message',L('Private link copied. Share it only with the intended person.','私有链接已复制，请仅分享给指定的人。'),'success');}catch{notice('#share-message',L('Clipboard access was blocked. Keep this page open and enable clipboard access.','剪贴板权限被阻止，请保留此页面并允许复制。'),'error');}};propertyData.access=[...(propertyData.access||[]),{id:response.id,role:response.role,label:$('#share-label').value.trim(),created_at:new Date().toISOString()}];}catch(error){notice('#share-message',errorText(error),'error');}finally{button.disabled=false;}};
 panel.querySelectorAll('[data-revoke]').forEach(button=>button.onclick=async()=>{if(!window.confirm(L('Revoke this private access link?','撤销此私有访问链接吗？')))return;try{await api(path+'/access/'+encodeURIComponent(button.dataset.revoke)+'/revoke',{method:'POST'});await loadProperty();}catch(error){notice('#share-message',errorText(error),'error');}});
 $('#export-property').onclick=async()=>{try{downloadJSON(await api(path+'/export'),'domic-property-'+propertyId+'.json');}catch(error){notice('#share-message',errorText(error),'error');}};
}
async function uploadAndRead(){
 if(busy||!selectedFile)return;requireWrite();setBusy(true);notice('#intake-message');setStage('processing');readingController=new AbortController();
 try{const form=new FormData();form.append('file',selectedFile,selectedFile.name);form.append('uploader_label',$('#uploader-label')?.value.trim()||'');const response=await api(path+'/documents',{method:'POST',body:form,signal:readingController.signal});if(!response.document?.id)throw new APIError('invalid_response');intake.document=response.document;setPreview(selectedFile);await runExtraction(readingController.signal);}
 catch(error){if(intake?.document){showReadFailure(error);}else{setStage('upload');notice('#intake-message',errorText(error),'error');if(error.code==='duplicate_document')await loadProperty();}}
 finally{setBusy(false);readingController=null;}
}
async function runExtraction(signal){
 const result=await api('/documents/'+encodeURIComponent(intake.document.id)+'/extract',{method:'POST',json:{locale:'en-GB',request_id:crypto.randomUUID()},signal});
 if(!result.document||!result.draft||!['review','partial','unreadable','unrelated'].includes(result.outcome))throw new APIError('invalid_response');
 intake.document=result.document;intake.fields=prepareFields(result.draft,propertyData.property);intake.baseVersion=result.base_version||0;intake.recordId=result.record_id||null;intake.outcome=result.outcome;intake.saved=false;
 showReview();
}
function recoveryControls(message){
 setStage('review');$('#review-form').hidden=true;$('#reading-outcome').className='notice';$('#reading-outcome').innerHTML=`<p>${escape(message)}</p><p class="small">${L('The original is already stored for this property. No history record has been confirmed.','原件已保存在这栋房屋下，尚未确认历史记录。')}</p><div class="dialog-actions"><button type="button" class="button secondary" id="retry-extraction">${L('Retry reading','重试识别')}</button><button type="button" class="button secondary" id="replace-unreadable">${L('Choose another document','选择另一份单据')}</button><button type="button" class="button primary" id="manual-entry">${L('Enter details manually','手工填写')}</button></div>`;
 $('#retry-extraction').onclick=retryExtraction;$('#replace-unreadable').onclick=()=>{if(busy||!discardAllowed())return;freshIntake();};$('#manual-entry').onclick=()=>{if(busy)return;intake.fields=prepareFields(null,propertyData.property);intake.outcome='manual';showReview();};
}
function showReadFailure(error){intake.fields=null;intake.outcome='failed';recoveryControls(errorText(error));}
function showReview(){
 if(['unreadable','unrelated'].includes(intake.outcome)){recoveryControls(intake.outcome==='unreadable'?L('No usable receipt details could be read. Try a clearer complete document, or enter its details manually.','无法读到可用票据信息，请换用更清晰完整的单据，或手工填写。'):L('This appears unrelated to home maintenance. Check the original and upload a property document, or explicitly enter a relevant activity manually.','这份资料似乎与房屋维护无关，请核对原件并更换房屋单据，或明确手工填写相关活动。'));return;}
 setStage('review');$('#review-form').hidden=false;notice('#reading-outcome',intake.fields?.extraction?.status==='uncertain'?L('Please check whether this document belongs to home maintenance. Only keep facts you can verify.','请先确认此资料是否属于房屋维护，仅保留可以核实的事实。'):intake.outcome==='partial'?L('Some details need your help. Check the retained fields and fill only what you can verify. Nothing has been confirmed.','部分信息需要补充，请核对已读字段，仅填写能确认的内容，尚未确认记录。'):intake.outcome==='manual'?L('Manual entry. Record only work that belongs to this property; unknown values stay blank.','手工填写，仅记录属于这栋房屋的工作，未知值留空。'):L('Details are ready for review. Check the original, correct any errors, then confirm the record.','信息已整理，请对照原件核对并修改，再确认记录。'));
 renderEditor(intake.fields);notice('#review-validation');
}
async function retryExtraction(){if(busy||!intake?.document)return;setBusy(true);setStage('processing');readingController=new AbortController();try{await runExtraction(readingController.signal);}catch(error){showReadFailure(error);}finally{setBusy(false);readingController=null;}}
function resumedOutcome(result){
 // Saved human-reviewed records take priority over an earlier extraction result.
 if(result.record?.id)return 'review';
 const state=result.document?.state,extracted=result.draft?.extraction?.status;
 if(state==='extraction_failed')return 'failed';
 if(state==='unreadable'||['no_text','unreadable'].includes(extracted))return 'unreadable';
 if(state==='unrelated'||extracted==='unrelated')return 'unrelated';
 if(state==='partial'||['partial','uncertain'].includes(extracted))return 'partial';
 return result.draft?'review':'manual';
}
async function resumeDocument(documentId){
 if(busy||!canWrite()||!discardAllowed())return;freshIntake();$('#intake-dialog').showModal();setStage('processing');setBusy(true);
 try{const result=await api('/documents/'+encodeURIComponent(documentId));intake.document=result.document;intake.fields=prepareFields(result.record?.fields||result.draft,propertyData.property);intake.recordId=result.record?.id||null;intake.baseVersion=result.record?.version||0;intake.outcome=resumedOutcome(result);
 if(canOriginal()){try{setPreview(await api('/documents/'+encodeURIComponent(documentId)+'/original',{binary:true}));}catch(error){setPreview(null);$('#intake-original').textContent=errorText(error);notice('#intake-message',L('The saved fields are available, but the original could not be loaded.','已保存字段可用，但原件暂时无法载入。'),'error');}}else setPreview(null);
 if(intake.outcome==='failed')showReadFailure(new APIError(result.document.last_error||'extraction_failed'));else showReview();
 if(['unreadable','unrelated','failed'].includes(intake.outcome))return;
 // A stored draft can be edited immediately; re-reading remains an explicit choice.
 const button=document.createElement('button');button.type='button';button.className='text-button';button.textContent=L('Read stored original again','重新识别云端原件');button.onclick=()=>{collectEditor(intake.fields);if(window.confirm(L('Replace this proposal with a new reading? The saved record will change only after you confirm.','重新识别并替换当前草稿吗？已保存记录仅在你确认后更新。')))retryExtraction();};$('#reading-outcome').append(button);
 }catch(error){setStage('upload');notice('#intake-message',errorText(error),'error');}finally{setBusy(false);}
}
async function editRecord(recordId){const record=(propertyData.records||[]).find(item=>item.id===recordId);if(!record||!canWrite())return;$('#record-dialog').close();await resumeDocument(record.document_id);}
async function openRecord(recordId){const record=(propertyData.records||[]).find(item=>item.id===recordId);if(!record)return;currentRecord=record;$('#record-title').textContent=record.fields?.service?.summary||L('Property record','房屋记录');$('#record-detail').innerHTML=recordSummary(record.fields||{},propertyData.property,{full:propertyData.role!=='buyer'});$('#record-original').hidden=!canOriginal()||!record.document_id;$('#edit-record').hidden=!canWrite();$('#record-dialog').showModal();
 if(canOriginal()){const button=document.createElement('button');button.className='text-button';button.textContent=L('View revision history','查看修改历史');button.onclick=async()=>{button.disabled=true;try{const response=await api('/records/'+encodeURIComponent(record.id)+'/history');const box=document.createElement('div');box.className='revision-list';box.innerHTML=(response.versions||[]).map(version=>`<details><summary>${L('Version','版本')} ${escape(version.version)} · ${escape(version.actor_label||'')} · ${escape(version.created_at)}</summary>${recordSummary(version.fields||{},propertyData.property)}</details>`).join('');button.after(box);}catch(error){notice('#page-message',errorText(error),'error');button.disabled=false;}};$('#record-detail').append(button);}}
async function openOriginal(documentId){if(!canOriginal())return;try{const blob=await api('/documents/'+encodeURIComponent(documentId)+'/original',{binary:true});const url=URL.createObjectURL(blob);openedOriginalUrls.push(url);const anchor=document.createElement('a');anchor.href=url;anchor.target='_blank';anchor.rel='noopener';anchor.click();}catch(error){notice('#page-message',errorText(error),'error');}}
async function confirmSave(){if(busy||!intake?.fields||!$('#confirm-check').checked)return;requireWrite();setBusy(true);notice('#confirm-message');try{const response=await api(path+'/records',{method:'POST',json:{document_id:intake.document.id,fields:intake.fields,confirm:true,base_version:intake.baseVersion}});if(!response.record?.id)throw new APIError('invalid_response');intake.saved=true;$('#confirm-dialog').close();$('#intake-dialog').close();await loadProperty();notice('#page-message',L('Confirmed and saved to this property in the cloud. The original remains attached.','已确认并保存到云端的这栋房屋，原件关联已保留。'),'success');intake=null;selectedFile=null;releasePreview();}
 catch(error){notice('#confirm-message',errorText(error),'error');if(error.code==='version_conflict'){let button=$('#reload-latest');if(!button){button=document.createElement('button');button.id='reload-latest';button.type='button';button.className='button secondary';button.textContent=L('Reload latest record','重新载入最新记录');$('#confirm-message').append(button);}button.onclick=async()=>{const id=intake.document.id;if(!window.confirm(L('Discard these unsaved edits and load the latest saved version?','放弃当前未保存修改，并载入最新保存版本吗？')))return;intake.saved=true;$('#confirm-dialog').close();await resumeDocument(id);};}}
 finally{setBusy(false);}}

$('#add-document').onclick=openNew;$('#close-intake').onclick=closeIntake;$('#cancel-upload').onclick=closeIntake;$('#intake-dialog').oncancel=event=>{event.preventDefault();closeIntake();};$('#document-file').onchange=event=>acceptFile(event.target.files[0]);$('#read-document').onclick=uploadAndRead;$('#choose-another').onclick=()=>{if(!busy&&discardAllowed())freshIntake();};$('#cancel-reading').onclick=()=>readingController?.abort();
$('#open-intake-original').onclick=()=>{if(!previewUrl)return;const link=document.createElement('a');link.href=previewUrl;link.target='_blank';link.rel='noopener';link.click();};
$('#record-original').onclick=()=>currentRecord&&openOriginal(currentRecord.document_id);$('#edit-record').onclick=()=>currentRecord&&editRecord(currentRecord.id);
$('#review-form').onsubmit=event=>{event.preventDefault();if(busy||!intake?.fields)return;collectEditor(intake.fields);const error=validationText(intake.fields);if(error){notice('#review-validation',error,'error');return;}$('#confirmation-summary').innerHTML=recordSummary(intake.fields,propertyData.property);$('#confirm-check').checked=false;$('#confirm-save').disabled=true;notice('#confirm-message');$('#confirm-dialog').showModal();};
$('#confirm-check').onchange=()=>$('#confirm-save').disabled=busy||!$('#confirm-check').checked;$('#confirm-save').onclick=confirmSave;
const zone=$('#drop-zone');for(const event of ['dragenter','dragover'])zone.addEventListener(event,e=>{e.preventDefault();zone.classList.add('dragover');});for(const event of ['dragleave','drop'])zone.addEventListener(event,e=>{e.preventDefault();zone.classList.remove('dragover');});zone.addEventListener('drop',event=>{if(event.dataTransfer.files.length!==1){notice('#intake-message',L('Choose one document at a time.','每次请选择一份单据。'),'error');return;}acceptFile(event.dataTransfer.files[0]);});
window.addEventListener('beforeunload',event=>{if(unsaved()){event.preventDefault();event.returnValue='';}});window.addEventListener('pagehide',()=>{releasePreview();openedOriginalUrls.forEach(url=>URL.revokeObjectURL(url));});
initUI(()=>{renderWorkspace();if(intake?.fields&& !$('#review-stage').hidden){collectEditor(intake.fields);showReview();}if($('#confirm-dialog').open&&intake?.fields)$('#confirmation-summary').innerHTML=recordSummary(intake.fields,propertyData.property);});
try{status=await api('/status',{publicRequest:true});$('#upload-limits').textContent=L('JPG, PNG, WebP or PDF · Up to ','JPG、PNG、WebP 或 PDF · 最大 ')+Math.round((status.max_file_bytes||6291456)/1024/1024)+' MB';if(!status.storage_ready)throw new APIError('not_configured');await loadProperty();}
catch(error){$('#access-state').innerHTML=`<h2>${L('This property workspace could not be opened','暂时无法打开房屋工作台')}</h2><p class="muted">${escape(errorText(error))}</p><button class="button secondary" id="reload-workspace">${L('Try again','重试')}</button>`;$('#reload-workspace').onclick=()=>location.reload();}

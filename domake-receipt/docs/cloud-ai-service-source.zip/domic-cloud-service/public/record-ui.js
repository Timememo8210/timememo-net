import {blankRecord, get, set, inspect} from './record-core.js';
import {toEnglish} from './record-i18n.js';
import {$, $$, L, escape, valueAt, money, summaryHTML} from './ui.js';
export const enums={
  category:{plumbing:['Plumbing','水暖'],electrical:['Electrical','电气'],hvac:['Heating / HVAC','暖通'],roofing:['Roofing','屋顶'],landscaping:['Landscaping','园艺'],appliance:['Appliance','家电'],renovation:['Renovation','翻修'],cleaning:['Cleaning','清洁'],general:['General maintenance','一般维护'],other:['Other','其他'],unknown:['Unknown','未知']},
  type:{receipt:['Receipt','收据'],invoice:['Invoice','账单／发票'],estimate:['Estimate','报价单'],warranty:['Warranty','保修文件'],other:['Other','其他'],unknown:['Unknown','未知']},
  payment:{paid:['Paid','已付款'],unpaid:['Unpaid','未付款'],partial:['Part paid','部分付款'],unknown:['Unknown','未知']},
  completion:{completed:['Completed','已完成'],planned:['Planned','计划中'],unknown:['Unknown','未知']},
  change:{repair:['Repair','维修'],replacement:['Replacement','更换'],installation:['Installation','安装'],improvement:['Improvement','改造'],maintenance:['Maintenance','保养'],inspection:['Inspection','检查'],unknown:['Unknown','未知']}
};
export function enumLabel(group,key){const pair=enums[group]?.[key];return pair?L(...pair):key||L('Unknown','未知');}
export const primary=[
 ['service.summary',['Work performed','工作内容'],'textarea',null,true],['service.date',['Actual service date','实际服务日期'],'date'],
 ['provider.organization_name',['Service company','服务公司'],'text'],['provider.person_name',['Person who performed the work','实际施工者'],'text'],
 ['provider.name',['Provider display name','服务商显示名称'],'text'],['property.service_address',['Work address on the document','单据中的施工地址'],'text',null,true],
 ['service.change_type',['Type of work / change','工作／变更类型'],'select','change'],['service.category',['Home system','房屋系统'],'select','category'],
 ['service.location',['Location in the home','房屋中的位置'],'text'],['amount.total',['Document total','单据总金额'],'number'],
 ['amount.currency',['Currency','币种'],'text'],['document.type',['Document type','单据类型'],'select','type'],
 ['amount.payment_status',['Payment status','付款状态'],'select','payment'],['service.completion_status',['Work status','施工状态'],'select','completion']
];
const extra=[['document.issue_date',['Issue date','开票日期'],'date'],['document.number',['Document number','单据编号'],'text'],['provider.phone',['Provider phone','服务商电话'],'text'],['provider.address',['Provider office address','服务商办公地址'],'text',null,true],['details.asset_model',['Equipment model','设备型号'],'text'],['details.asset_serial',['Equipment serial number','设备序列号'],'text'],['details.warranty',['Warranty information','保修信息'],'textarea',null,true],['details.permit_number',['Permit number','许可编号'],'text'],['notes',['Notes','备注'],'textarea',null,true]];
export function prepareFields(data,property){
  const base=blankRecord();
  if(data)for(const [key,value] of Object.entries(data))base[key]=value&&typeof value==='object'&&!Array.isArray(value)?{...(base[key]||{}),...structuredClone(value)}:structuredClone(value);
  base.property={...base.property,id:property.name,uid:property.id};
  base.review={status:'draft',missing_fields:[],warnings:[],edited_fields:[],...base.review};
  base.review.edited_fields||=[];base.items||=[];base.evidence||=[];
  return base;
}
function inputHTML(record,fields){return fields.map(([path,pair,type,group,full])=>{
  const value=get(record,path),id='field-'+path.replaceAll('.','-');let control;
  if(type==='select')control=`<select id="${id}" data-field="${path}">${Object.entries(enums[group]).map(([key,label])=>`<option value="${key}" ${value===key?'selected':''}>${escape(L(...label))}</option>`).join('')}</select>`;
  else if(type==='textarea')control=`<textarea id="${id}" data-field="${path}" maxlength="4000" ${path==='service.summary'?'required':''}>${escape(value)}</textarea>`;
  else control=`<input id="${id}" data-field="${path}" type="${type}" value="${escape(value)}" ${type==='number'?'step="0.01" min="0" inputmode="decimal"':''} ${type==='text'?`maxlength="${path==='amount.currency'?3:600}"`:''}>`;
  return `<div class="field ${full?'full':''}"><label for="${id}">${escape(L(...pair))}${path==='service.summary'?' *':''}</label>${control}${path==='service.date'?`<small>${L('Leave unknown dates blank; issue date is separate.','未知日期留空，开票日期单独记录。')}</small>`:''}</div>`;
}).join('');}
export function renderEditor(record){
  $('#review-fields').innerHTML=inputHTML(record,primary);
  $('#review-extra-fields').innerHTML=inputHTML(record,extra)+`<div class="field full"><label>${L('Line items','费用明细')}</label><div id="line-items">${record.items.map((item,index)=>`<div class="item-row"><input data-item="${index}" data-item-key="description" aria-label="${L('Item description','明细内容')}" value="${escape(item.description)}"><input data-item="${index}" data-item-key="amount" aria-label="${L('Item amount','明细金额')}" type="number" min="0" step="0.01" value="${escape(item.amount)}"></div>`).join('')}</div></div>`;
  $('#review-evidence').innerHTML=record.evidence.length?record.evidence.map(item=>`<p class="small muted"><strong>${escape(item.field)}</strong> · ${L('Page','页')} ${escape(item.page)}<br>“${escape(item.quote)}”</p>`).join(''):`<p class="small muted">${L('No source quotes available.','没有可用的原文证据。')}</p>`;
}
export function collectEditor(record){
  $$('[data-field]').forEach(input=>{let value=input.value.trim()||null;if(input.dataset.field==='amount.total'&&value!==null)value=Number(value);if(input.dataset.field==='amount.currency'&&value)value=value.toUpperCase();if(get(record,input.dataset.field)!==value&&!record.review.edited_fields.includes(input.dataset.field))record.review.edited_fields.push(input.dataset.field);set(record,input.dataset.field,value);});
  $$('[data-item]').forEach(input=>{record.items[+input.dataset.item][input.dataset.itemKey]=input.dataset.itemKey==='amount'?(input.value===''?null:Number(input.value)):(input.value.trim()||null);});
  return record;
}
export function validationText(record){return inspect(record,{confirm:true}).errors.map(text=>L(toEnglish(text),text)).join(' ');}
export function recordSummary(record,property,{full=true}={}){
 const rows=[[L('Property','归属房屋'),property?.name],[L('Permanent property reference','永久房屋编号'),property?.passport_id||property?.id],...primary.map(([path,pair,type,group])=>[L(...pair),type==='select'?enumLabel(group,valueAt(record,path)):valueAt(record,path)]),[L('Issue date','开票日期'),valueAt(record,'document.issue_date')]];
 if(full){rows.push(...extra.filter(([path])=>path!=='document.issue_date').map(([path,pair])=>[L(...pair),valueAt(record,path)]));for(const [index,item] of (record.items||[]).entries())rows.push([L('Line item ','明细 ')+(index+1),(item.description||'')+' · '+money(item.amount,record.amount?.currency)]);}
 return summaryHTML(rows);
}
export function timelineHTML(records,{canEdit=false,canOriginal=false}={}){
 const sorted=[...records].sort((a,b)=>{const x=a.fields?.service?.date,y=b.fields?.service?.date;return x&&y?y.localeCompare(x):x?-1:y?1:0;});
 return sorted.map(record=>{const f=record.fields||{},estimate=f.document?.type==='estimate';return `<article class="timeline-card"><div class="timeline-date">${escape(f.service?.date||L('Service date unknown','服务日期未知'))}</div><div><span class="tag ${record.status==='confirmed'?'':'amber'}">${record.status==='confirmed'?L('Confirmed','已确认'):L('Draft','草稿')}</span> <span class="tag ${estimate?'amber':''}">${escape(enumLabel('type',f.document?.type))}</span><h3>${escape(f.service?.summary||L('Work summary not provided','尚未提供工作内容'))}</h3><p class="muted">${escape(f.provider?.organization_name||f.provider?.name||L('Provider unknown','服务商未知'))}${f.provider?.person_name?' · '+escape(f.provider.person_name):''}</p><p class="small muted">${estimate?L('Estimate · not proof of completed work or payment','报价 · 不代表实际完工或付款'):escape(enumLabel('completion',f.service?.completion_status))}</p><div class="timeline-actions"><button class="text-button" data-record="${escape(record.id)}">${L('View record','查看记录')}</button>${canEdit?`<button class="text-button" data-edit="${escape(record.id)}">${L('Edit and reconfirm','修改并重新确认')}</button>`:''}${canOriginal&&record.document_id?`<button class="text-button" data-original="${escape(record.document_id)}">${L('Original document ↗','原始单据 ↗')}</button>`:''}</div></div><div class="timeline-amount">${escape(money(f.amount?.total,f.amount?.currency))}</div></article>`;}).join('');
}
export function renderOriginal(host,blob){const url=URL.createObjectURL(blob);host.replaceChildren();if(blob.type==='application/pdf'){const note=document.createElement('p');note.className='small muted';note.textContent=L('If this preview is blank, use Open original.','若预览空白，请点击打开原件。');const frame=document.createElement('iframe');frame.src=url;frame.title=L('Original PDF','原始 PDF');host.append(note,frame);}else{const img=document.createElement('img');img.src=url;img.alt=L('Original document','原始单据');host.append(img);}return url;}

import {L} from './ui.js';
export class APIError extends Error { constructor(code,status=0){super(code);this.code=code;this.status=status;} }
export function makeAPI(getToken) {
  return async function request(path,{method='GET',json,body,signal,binary=false,timeout=45000,publicRequest=false}={}) {
    const controller=new AbortController();let timedOut=false;
    const abort=()=>controller.abort();
    if(signal?.aborted)abort();else signal?.addEventListener('abort',abort,{once:true});
    const timer=setTimeout(()=>{timedOut=true;controller.abort();},timeout);
    try {
      const headers={};
      if(!publicRequest){const token=getToken();if(!token)throw new APIError('access_required');headers.Authorization=`Bearer ${token}`;}
      if(json!==undefined){headers['Content-Type']='application/json';body=JSON.stringify(json);}
      const response=await fetch('/api/cloud'+path,{method,headers,body,signal:controller.signal,cache:'no-store',credentials:'omit'});
      if(binary&&response.ok)return await response.blob();
      let data;try{data=await response.json();}catch{throw new APIError('invalid_response',response.status);}
      if(!response.ok)throw new APIError(data?.error?.code||'request_failed',response.status);
      return data;
    }catch(error){if(timedOut)throw new APIError('timeout');if(controller.signal.aborted)throw new APIError('cancelled');if(error instanceof APIError)throw error;throw new APIError('network_error');}
    finally{clearTimeout(timer);signal?.removeEventListener('abort',abort);}
  };
}
export function errorText(error) {
  const messages={
    access_required:L('Open the private property link, or enter your management access code.','请打开私有房屋链接，或输入管理访问码。'),
    unauthorized:L('This access link or code is not valid. Request a current link from the property owner.','此访问链接或访问码无效，请向房屋主人获取有效链接。'),
    forbidden:L('This access link does not permit that action.','当前访问链接无权执行此操作。'),
    duplicate_document:L('This original is already attached to this property. Open it from the documents awaiting review or the timeline.','此原件已归属这栋房屋，请从待核对单据或时间线打开。'),
    version_conflict:L('This record changed since you opened it. Your changes were not saved. Reload the latest record, then review and apply your correction again.','此记录在你打开后已被修改，你的更改尚未保存。请重新载入最新记录，再核对并修改。'),
    file_too_large:L('The file is too large. Choose an image or PDF no larger than 6 MB.','文件过大，请选择不超过 6 MB 的图片或 PDF。'),
    unsupported_file:L('Choose a JPG, PNG, WebP or supported PDF document.','请选择 JPG、PNG、WebP 或受支持的 PDF。'),
    not_configured:L('The document reader is not enabled. Ask the administrator to test and enable a configuration, or enter details manually.','单据识别尚未启用，请管理员测试并启用配置，或手工填写。'),
    reader_disabled:L('The document reader is not enabled. You can enter the details manually.','单据识别尚未启用，可以手工填写。'),
    insufficient_credits:L('The AI service has insufficient credits. Ask the administrator to check its account; manual entry is available.','AI 服务额度不足，请管理员检查账户；仍可手工填写。'),
    rate_limited:L('Too many requests. Please wait briefly before trying again.','请求过多，请稍候重试。'),
    timeout:L('The request took too long. Refresh to check the latest state before retrying. The original may already be retained in the cloud.','请求超时。请刷新查看最新状态后再重试，原件可能已保留在云端。'),
    cancelled:L('The request was cancelled. An uploaded original remains attached to this property; no history record is automatically confirmed.','请求已取消。已上传原件仍归属此房屋，不会自动确认历史记录。'),
    invalid_response:L('The service returned an unusable response. No record was automatically confirmed.','服务返回的内容无法使用，不会自动确认记录。'),
    network_error:L('The service could not be reached. Check your connection and refresh the latest state before retrying.','无法连接服务，请检查网络，并刷新最新状态后重试。'),
    config_not_tested:L('Test this saved configuration successfully before enabling it.','请先成功测试当前已保存配置，再启用。'),
    pdf_not_supported:L('This reader has not been verified for PDFs. Choose an image or enter the PDF details manually.','当前识别服务尚未验证 PDF 能力，请使用图片或手工录入 PDF。'),
    new_key_required:L('Enter a new API key for this provider or endpoint. The existing key cannot be reused at a changed address.','请为当前服务商或地址输入新 API 密钥，原密钥不能复用于已更换的地址。'),
    endpoint_not_allowed:L('This API endpoint is not allowed. Check the provider endpoint or ask the administrator to configure an approved address.','此 API 地址不被允许，请核对服务商地址或请管理员配置允许的地址。'),
    daily_limit_reached:L('The daily reading limit has been reached. You can enter details manually or ask the administrator to review the limit.','已达到每日识别限额，可以手工填写，或请管理员检查限额。'),
    extraction_in_progress:L('This original is already being read. Wait briefly, then refresh its latest state before trying again.','此原件正在识别，请稍候刷新最新状态后再操作。'),
    invalid_record:L('The record could not be validated. Check the work summary, dates, amounts and status fields; leave unknown values blank.','记录未通过校验，请检查工作摘要、日期、金额和状态；未知值请留空。'),
    invalid_request:L('Check the required fields and try again.','请检查必填字段后重试。'),
  };
  const aliases={access_denied:'forbidden',admin_required:'forbidden',invalid_file:'unsupported_file',configuration_not_tested:'config_not_tested',provider_pdf_unsupported:'pdf_not_supported'};
  return messages[aliases[error?.code]||error?.code]||(error?.status===401?messages.unauthorized:error?.status===403?messages.forbidden:error?.status===422?messages.invalid_record:L('The request could not be completed. Refresh and try again; do not assume that it was saved.','请求未能完成，请刷新后重试；请勿视为已保存。'));
}

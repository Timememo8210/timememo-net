import { sqliteTable, text, integer, real, index, uniqueIndex, primaryKey } from 'drizzle-orm/sqlite-core';

export const properties = sqliteTable('properties', {
 id: text('id').primaryKey(), passportId: text('passport_id').notNull(), name: text('name').notNull(), address: text('address').notNull(), ownerLabel: text('owner_label').notNull(), requestId: text('request_id').notNull(), createdAt: text('created_at').notNull(), updatedAt: text('updated_at').notNull(),
}, t => [uniqueIndex('properties_passport_idx').on(t.passportId),uniqueIndex('properties_request_idx').on(t.requestId)]);

export const accessTokens = sqliteTable('access_tokens', {
 id:text('id').primaryKey(), propertyId:text('property_id').notNull().references(()=>properties.id), role:text('role').notNull(), label:text('label').notNull(), tokenHash:text('token_hash').notNull(), externalUserId:text('external_user_id'), createdAt:text('created_at').notNull(), revokedAt:text('revoked_at'),
}, t=>[uniqueIndex('access_hash_idx').on(t.tokenHash),index('access_property_idx').on(t.propertyId)]);

export const documents = sqliteTable('documents', {
 id:text('id').primaryKey(), propertyId:text('property_id').notNull().references(()=>properties.id), name:text('name').notNull(), mimeType:text('mime_type').notNull(), sizeBytes:integer('size_bytes').notNull(), sha256:text('sha256').notNull(), storageKey:text('storage_key').notNull(), state:text('state').notNull(), uploadedBy:text('uploaded_by').notNull(), uploaderLabel:text('uploader_label').notNull(), analysisJson:text('analysis_json'), lastError:text('last_error'), leaseId:text('lease_id'), leaseUntil:integer('lease_until'), createdAt:text('created_at').notNull(), updatedAt:text('updated_at').notNull(),
}, t=>[uniqueIndex('documents_property_hash_idx').on(t.propertyId,t.sha256),index('documents_property_created_idx').on(t.propertyId,t.createdAt)]);

export const records = sqliteTable('records', {
 id:text('id').primaryKey(), propertyId:text('property_id').notNull().references(()=>properties.id), documentId:text('document_id').notNull().references(()=>documents.id), version:integer('version').notNull(), status:text('status').notNull(), fieldsJson:text('fields_json').notNull(), serviceDate:text('service_date'), editNonce:text('edit_nonce').notNull(), createdAt:text('created_at').notNull(), updatedAt:text('updated_at').notNull(),
},t=>[uniqueIndex('records_document_idx').on(t.documentId),index('records_property_date_idx').on(t.propertyId,t.serviceDate)]);

export const recordVersions = sqliteTable('record_versions', {
 recordId:text('record_id').notNull().references(()=>records.id), version:integer('version').notNull(), fieldsJson:text('fields_json').notNull(), actorLabel:text('actor_label').notNull(), actorId:text('actor_id').notNull(), createdAt:text('created_at').notNull(),
},t=>[primaryKey({columns:[t.recordId,t.version]})]);

export const aiConfigs = sqliteTable('ai_configs', {
 id:text('id').primaryKey(), provider:text('provider').notNull(), endpoint:text('endpoint').notNull(), model:text('model').notNull(), keyCipher:text('key_cipher').notNull(), keyHint:text('key_hint').notNull(), testOk:integer('test_ok').notNull().default(0), testedAt:text('tested_at'), pdfSupported:integer('pdf_supported').notNull().default(0), testMessage:text('test_message'), createdAt:text('created_at').notNull(),
});
export const settings = sqliteTable('settings',{ key:text('key').primaryKey(), value:text('value').notNull() });
export const auditEvents = sqliteTable('audit_events',{
 id:text('id').primaryKey(), action:text('action').notNull(), propertyId:text('property_id'), actorId:text('actor_id').notNull(), actorLabel:text('actor_label').notNull(), details:text('details').notNull(), createdAt:text('created_at').notNull(),
},t=>[index('audit_created_idx').on(t.createdAt)]);
export const usageEvents = sqliteTable('usage_events',{
 id:text('id').primaryKey(), day:text('day').notNull(), propertyId:text('property_id'), actorId:text('actor_id').notNull(), configId:text('config_id').notNull(), model:text('model').notNull(), state:text('state').notNull(), cost:real('cost'), elapsedMs:integer('elapsed_ms'), createdAt:text('created_at').notNull(),
},t=>[index('usage_day_idx').on(t.day)]);
export const extractionAttempts=sqliteTable('extraction_attempts',{
 documentId:text('document_id').notNull().references(()=>documents.id),requestId:text('request_id').notNull(),state:text('state').notNull(),resultJson:text('result_json'),errorCode:text('error_code'),errorStatus:integer('error_status'),createdAt:text('created_at').notNull(),
},t=>[primaryKey({columns:[t.documentId,t.requestId]})]);

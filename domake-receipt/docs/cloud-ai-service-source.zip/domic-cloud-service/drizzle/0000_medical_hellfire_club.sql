CREATE TABLE `access_tokens` (
	`id` text PRIMARY KEY NOT NULL,
	`property_id` text NOT NULL,
	`role` text NOT NULL,
	`label` text NOT NULL,
	`token_hash` text NOT NULL,
	`external_user_id` text,
	`created_at` text NOT NULL,
	`revoked_at` text,
	FOREIGN KEY (`property_id`) REFERENCES `properties`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `access_hash_idx` ON `access_tokens` (`token_hash`);--> statement-breakpoint
CREATE INDEX `access_property_idx` ON `access_tokens` (`property_id`);--> statement-breakpoint
CREATE TABLE `ai_configs` (
	`id` text PRIMARY KEY NOT NULL,
	`provider` text NOT NULL,
	`endpoint` text NOT NULL,
	`model` text NOT NULL,
	`key_cipher` text NOT NULL,
	`key_hint` text NOT NULL,
	`test_ok` integer DEFAULT 0 NOT NULL,
	`tested_at` text,
	`pdf_supported` integer DEFAULT 0 NOT NULL,
	`test_message` text,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `audit_events` (
	`id` text PRIMARY KEY NOT NULL,
	`action` text NOT NULL,
	`property_id` text,
	`actor_id` text NOT NULL,
	`actor_label` text NOT NULL,
	`details` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `audit_created_idx` ON `audit_events` (`created_at`);--> statement-breakpoint
CREATE TABLE `documents` (
	`id` text PRIMARY KEY NOT NULL,
	`property_id` text NOT NULL,
	`name` text NOT NULL,
	`mime_type` text NOT NULL,
	`size_bytes` integer NOT NULL,
	`sha256` text NOT NULL,
	`storage_key` text NOT NULL,
	`state` text NOT NULL,
	`uploaded_by` text NOT NULL,
	`uploader_label` text NOT NULL,
	`analysis_json` text,
	`last_error` text,
	`lease_id` text,
	`lease_until` integer,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL,
	FOREIGN KEY (`property_id`) REFERENCES `properties`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `documents_property_hash_idx` ON `documents` (`property_id`,`sha256`);--> statement-breakpoint
CREATE INDEX `documents_property_created_idx` ON `documents` (`property_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `properties` (
	`id` text PRIMARY KEY NOT NULL,
	`passport_id` text NOT NULL,
	`name` text NOT NULL,
	`address` text NOT NULL,
	`owner_label` text NOT NULL,
	`request_id` text NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `properties_passport_idx` ON `properties` (`passport_id`);--> statement-breakpoint
CREATE UNIQUE INDEX `properties_request_idx` ON `properties` (`request_id`);--> statement-breakpoint
CREATE TABLE `record_versions` (
	`record_id` text NOT NULL,
	`version` integer NOT NULL,
	`fields_json` text NOT NULL,
	`actor_label` text NOT NULL,
	`actor_id` text NOT NULL,
	`created_at` text NOT NULL,
	PRIMARY KEY(`record_id`, `version`),
	FOREIGN KEY (`record_id`) REFERENCES `records`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `records` (
	`id` text PRIMARY KEY NOT NULL,
	`property_id` text NOT NULL,
	`document_id` text NOT NULL,
	`version` integer NOT NULL,
	`status` text NOT NULL,
	`fields_json` text NOT NULL,
	`service_date` text,
	`edit_nonce` text NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL,
	FOREIGN KEY (`property_id`) REFERENCES `properties`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`document_id`) REFERENCES `documents`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `records_document_idx` ON `records` (`document_id`);--> statement-breakpoint
CREATE INDEX `records_property_date_idx` ON `records` (`property_id`,`service_date`);--> statement-breakpoint
CREATE TABLE `settings` (
	`key` text PRIMARY KEY NOT NULL,
	`value` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `usage_events` (
	`id` text PRIMARY KEY NOT NULL,
	`day` text NOT NULL,
	`property_id` text,
	`actor_id` text NOT NULL,
	`config_id` text NOT NULL,
	`model` text NOT NULL,
	`state` text NOT NULL,
	`cost` real,
	`elapsed_ms` integer,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `usage_day_idx` ON `usage_events` (`day`);
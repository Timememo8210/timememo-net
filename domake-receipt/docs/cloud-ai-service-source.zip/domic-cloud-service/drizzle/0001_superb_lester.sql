CREATE TABLE `extraction_attempts` (
	`document_id` text NOT NULL,
	`request_id` text NOT NULL,
	`state` text NOT NULL,
	`result_json` text,
	`error_code` text,
	`error_status` integer,
	`created_at` text NOT NULL,
	PRIMARY KEY(`document_id`, `request_id`),
	FOREIGN KEY (`document_id`) REFERENCES `documents`(`id`) ON UPDATE no action ON DELETE no action
);

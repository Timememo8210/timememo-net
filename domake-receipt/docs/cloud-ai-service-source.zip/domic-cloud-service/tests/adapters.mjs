import { DatabaseSync } from 'node:sqlite';
import { createHash } from 'node:crypto';

const cloneRow = row => row == null ? null : Object.fromEntries(Object.entries(row));
const numeric = value => typeof value === 'bigint' ? Number(value) : value;
const binding = value => value instanceof ArrayBuffer ? new Uint8Array(value) : typeof value === 'boolean' ? Number(value) : value;

class D1Statement {
  constructor(owner, sql, values = []) { this.owner = owner; this.sql = sql; this.values = values; }
  bind(...values) { return new D1Statement(this.owner, this.sql, values.map(binding)); }
  execute() {
    const statement = this.owner.sqlite.prepare(this.sql);
    const returning = statement.columns().length > 0;
    const before = this.owner.sqlite.prepare('SELECT total_changes() AS n').get().n;
    let results = [], lastRow = 0;
    if (returning) results = statement.all(...this.values).map(cloneRow);
    else { const info = statement.run(...this.values); lastRow = numeric(info.lastInsertRowid); }
    const after = this.owner.sqlite.prepare('SELECT total_changes() AS n').get().n;
    return { success: true, results, meta: { changes: numeric(after - before), last_row_id: lastRow,
      duration: 0, rows_read: results.length, rows_written: numeric(after - before), served_by: 'node-sqlite-test' } };
  }
  async first(column) { const row = this.execute().results[0] ?? null; return column === undefined ? row : row?.[column] ?? null; }
  async all() { return this.execute(); }
  async run() { return this.execute(); }
  async raw({ columnNames = false } = {}) {
    const result = this.execute().results;
    const names = this.owner.sqlite.prepare(this.sql).columns().map(column => column.name);
    const rows = result.map(row => names.map(name => row[name]));
    return columnNames ? [names, ...rows] : rows;
  }
}

/** Implements the D1 surface used by this project, including atomic batch rollback. */
export class SqliteD1 {
  constructor() { this.sqlite = new DatabaseSync(':memory:'); this.sqlite.exec('PRAGMA foreign_keys = ON'); }
  prepare(sql) { return new D1Statement(this, sql); }
  async batch(statements) {
    this.sqlite.exec('BEGIN IMMEDIATE');
    try {
      const results = statements.map(statement => statement.execute());
      this.sqlite.exec('COMMIT');
      return results;
    } catch (error) { this.sqlite.exec('ROLLBACK'); throw error; }
  }
  async exec(sql) { this.sqlite.exec(sql); return { count: 1, duration: 0 }; }
  withSession() { return this; }
  close() { this.sqlite.close(); }
}

async function bytesOf(value) {
  if (typeof value === 'string') return new TextEncoder().encode(value);
  if (value instanceof Uint8Array) return value.slice();
  if (ArrayBuffer.isView(value)) return new Uint8Array(value.buffer, value.byteOffset, value.byteLength).slice();
  if (value instanceof ArrayBuffer) return new Uint8Array(value.slice(0));
  if (value?.arrayBuffer) return new Uint8Array(await value.arrayBuffer());
  if (value instanceof ReadableStream) return new Uint8Array(await new Response(value).arrayBuffer());
  throw new TypeError('Unsupported R2 test body');
}
function objectMeta(key, entry) {
  return { key, version: entry.version, size: entry.bytes.byteLength, etag: entry.etag,
    httpEtag: `"${entry.etag}"`, uploaded: new Date(entry.uploaded),
    httpMetadata: structuredClone(entry.httpMetadata), customMetadata: structuredClone(entry.customMetadata),
    checksums: {}, storageClass: 'Standard',
    writeHttpMetadata(headers) {
      const names = { contentType: 'Content-Type', contentLanguage: 'Content-Language', contentDisposition: 'Content-Disposition',
        contentEncoding: 'Content-Encoding', cacheControl: 'Cache-Control', cacheExpiry: 'Expires' };
      for (const [key, value] of Object.entries(entry.httpMetadata)) if (names[key]) headers.set(names[key], String(value));
    },
  };
}

/** In-memory private object store. No URL/public access mechanism is supplied. */
export class MemoryR2 {
  constructor() { this.objects = new Map(); }
  async put(key, value, options = {}) {
    const bytes = await bytesOf(value), etag = createHash('md5').update(bytes).digest('hex');
    const entry = { bytes, etag, version: crypto.randomUUID(), uploaded: new Date(),
      httpMetadata: options.httpMetadata || {}, customMetadata: options.customMetadata || {} };
    this.objects.set(key, entry);
    return objectMeta(key, entry);
  }
  async get(key, options = {}) {
    const entry = this.objects.get(key);
    if (!entry) return null;
    let bytes = entry.bytes.slice();
    const range = options.range;
    if (range && !(range instanceof Headers)) {
      const start = range.suffix ? Math.max(0, bytes.length - range.suffix) : range.offset || 0;
      bytes = bytes.slice(start, range.length ? start + range.length : undefined);
    }
    const response = new Response(bytes);
    return { ...objectMeta(key, entry), body: response.body, get bodyUsed() { return response.bodyUsed; },
      arrayBuffer: () => response.arrayBuffer(), text: () => response.text(), json: () => response.json(), blob: () => response.blob() };
  }
  async head(key) { const entry = this.objects.get(key); return entry ? objectMeta(key, entry) : null; }
  async delete(keys) { for (const key of Array.isArray(keys) ? keys : [keys]) this.objects.delete(key); }
  async list({ prefix = '', limit = 1000, cursor } = {}) {
    const entries = [...this.objects.entries()].filter(([key]) => key.startsWith(prefix) && (!cursor || key > cursor)).sort(([a], [b]) => a.localeCompare(b));
    const selected = entries.slice(0, limit);
    return { objects: selected.map(([key, value]) => objectMeta(key, value)), truncated: entries.length > limit,
      cursor: entries.length > limit ? selected.at(-1)?.[0] : undefined, delimitedPrefixes: [] };
  }
}

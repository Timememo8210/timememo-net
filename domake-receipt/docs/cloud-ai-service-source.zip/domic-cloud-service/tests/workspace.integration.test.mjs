import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { SqliteD1, MemoryR2 } from './adapters.mjs';
import { HAS_ROUTER, ROUTER_PATH, FAKE_ADMIN, FAKE_ENV_KEY, FAKE_NEW_KEY, FAKE_COMPAT_KEY,
  noNetwork, createHarness, initializeDatabase, PNG, ok, denied, property, grant, upload, fields, save,
  assertNoKeys, assertNoSecrets, mockProvider, validateStoredRecord } from './harness.mjs';

const realFetch = globalThis.fetch;
before(() => { globalThis.fetch = noNetwork; });
after(() => { globalThis.fetch = realFetch; });
const integration = (name, fn) => test(name, { skip: !HAS_ROUTER && `Router not yet available: ${ROUTER_PATH}` }, fn);
async function use(t, options) { const h = await createHarness(options); t.after(() => h.close()); return h; }

test('D1 adapter: binding, first/all/run and batch rollback match required contract', async () => {
  const db = new SqliteD1();
  try {
    const migrations = await initializeDatabase(db);
    assert.ok(migrations.length > 0);
    for (const name of ['properties', 'access_tokens', 'documents', 'records', 'record_versions', 'ai_configs', 'audit_events'])
      assert.ok(db.sqlite.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name=?").get(name), `Migration table missing: ${name}`);
    await db.exec('CREATE TABLE adapter_probe (id TEXT PRIMARY KEY, value INTEGER NOT NULL)');
    const insert = await db.prepare('INSERT INTO adapter_probe VALUES (?,?)').bind('one', 1).run();
    assert.equal(insert.meta.changes, 1);
    assert.deepEqual(await db.prepare('SELECT * FROM adapter_probe WHERE id=?').bind('one').first(), { id: 'one', value: 1 });
    assert.equal(await db.prepare('SELECT value FROM adapter_probe WHERE id=?').bind('missing').first('value'), null);
    await assert.rejects(db.batch([
      db.prepare('INSERT INTO adapter_probe VALUES (?,?)').bind('two', 2),
      db.prepare('INSERT INTO adapter_probe VALUES (?,?)').bind('one', 9),
    ]));
    assert.deepEqual((await db.prepare('SELECT id FROM adapter_probe').all()).results, [{ id: 'one' }]);
    const success = await db.batch([
      db.prepare('UPDATE adapter_probe SET value=? WHERE id=?').bind(3, 'one'),
      db.prepare('SELECT value FROM adapter_probe WHERE id=?').bind('one'),
    ]);
    assert.equal(success[0].meta.changes, 1); assert.equal(success[1].results[0].value, 3);
  } finally { db.close(); }
});

test('R2 adapter: private bytes persist and each authenticated read has an independent stream', async () => {
  const bucket = new MemoryR2(), bytes = Uint8Array.from([0, 255, 4, 10]);
  await bucket.put('private/random', bytes, { httpMetadata: { contentType: 'application/pdf' } });
  bytes[0] = 8;
  const first = await bucket.get('private/random'), second = await bucket.get('private/random');
  assert.deepEqual(new Uint8Array(await first.arrayBuffer()), Uint8Array.from([0, 255, 4, 10]));
  assert.deepEqual(new Uint8Array(await second.arrayBuffer()), Uint8Array.from([0, 255, 4, 10]));
  const headers = new Headers(); (await bucket.head('private/random')).writeHttpMetadata(headers);
  assert.equal(headers.get('Content-Type'), 'application/pdf');
  assert.equal((await bucket.list({ prefix: 'private/' })).objects.length, 1);
  await bucket.delete('private/random'); assert.equal(await bucket.get('private/random'), null);
});

integration('admin creates stable UUID homes; lists never disclose owner capability secrets', async t => {
  const h = await use(t), a = await property(h, 'A'), b = await property(h, 'B');
  assert.notEqual(a.id, b.id);
  const changed = ok(await h.call(`/properties/${a.id}`, { method: 'PATCH', body: { name: 'Renamed House', address: 'New displayed address', owner_label: 'New label' } }));
  assert.equal(changed.property.id, a.id);
  const list = ok(await h.call('/properties'));
  assert.equal(list.properties.length, 2);
  assertNoSecrets(list, [a.token, b.token, FAKE_ADMIN, FAKE_ENV_KEY]);
  const tokenRows = h.DB.sqlite.prepare('SELECT token_hash FROM access_tokens').all();
  assert.equal(tokenRows.length, 2);
  assert.ok(tokenRows.some(row => row.token_hash === createHash('sha256').update(a.token).digest('hex')));
  assert.ok(tokenRows.every(row => row.token_hash !== a.token && row.token_hash !== b.token));
  denied(await h.call('/properties', { token: a.token }));
  denied(await h.call('/properties', { token: a.token, method: 'POST', body: { name: 'Spoof', request_id: crypto.randomUUID() } }));
});

integration('owner A cannot read, alter, export or fetch originals from property B', async t => {
  const h = await use(t), a = await property(h, 'A'), b = await property(h, 'B');
  const original = await upload(h, b);
  ok(await save(h, b, original.document.id));
  for (const path of [`/properties/${b.id}`, `/properties/${b.id}/export`, `/documents/${original.document.id}`, `/documents/${original.document.id}/original`])
    denied(await h.call(path, { token: a.token }));
  denied(await h.call(`/properties/${b.id}/access`, { token: a.token, method: 'POST', body: { role: 'buyer', label: 'Not allowed' } }));
  denied(await h.call(`/properties/${b.id}`, { token: a.token, method: 'PATCH', body: { owner_label: 'Hijack' } }));
});

integration('cloud original bytes and server hash persist; no unauthenticated original URL exists', async t => {
  const h = await use(t), home = await property(h), original = await upload(h, home);
  const row = h.DB.sqlite.prepare('SELECT * FROM documents WHERE id=?').get(original.document.id);
  assert.equal(row.property_id, home.id);
  assert.equal(row.sha256, createHash('sha256').update(original.bytes).digest('hex'));
  assert.ok(h.BUCKET.objects.has(row.storage_key));
  assert.deepEqual(h.BUCKET.objects.get(row.storage_key).bytes, original.bytes);
  for (const token of [home.token, FAKE_ADMIN]) {
    const response = await h.raw(`/documents/${row.id}/original`, { token });
    assert.equal(response.status, 200);
    assert.match(response.headers.get('Content-Type') || '', /^image\/png/);
    assert.deepEqual(new Uint8Array(await response.arrayBuffer()), original.bytes);
  }
  denied(await h.call(`/documents/${row.id}/original`, { token: null }));
  assertNoKeys(original.document, ['storage_key', 'url', 'download_url', 'signed_url', 'public_url']);
  const detail = ok(await h.call(`/documents/${row.id}`, { token: home.token }));
  assertNoKeys(detail, ['storage_key', 'url', 'download_url', 'signed_url', 'public_url']);
});

integration('buyer sees only confirmed history and cannot read original, full export, revision history or write', async t => {
  const h = await use(t), home = await property(h), buyer = await grant(h, home, 'buyer');
  const original = await upload(h, home);
  const draft = ok(await save(h, home, original.document.id, { confirm: false })).record;
  assert.equal(ok(await h.call(`/properties/${home.id}`, { token: buyer.token })).records.length, 0);
  const record = ok(await save(h, home, original.document.id, { version: draft.version })).record;
  const body = ok(await h.call(`/properties/${home.id}`, { token: buyer.token }));
  assert.equal(body.role, 'buyer'); assert.equal(body.records.length, 1);
  if (Object.hasOwn(body, 'documents')) assert.deepEqual(body.documents, [], 'Buyer document container must be empty');
  if (Object.hasOwn(body, 'access')) assert.deepEqual(body.access, [], 'Buyer grant container must be empty');
  assertNoKeys(body, ['storage_key', 'sha256', 'source', 'evidence', 'extraction', 'notes']);
  assertNoSecrets(body, [home.token, buyer.token, 'PRIVATE OWNER NOTE']);
  for (const path of [`/documents/${original.document.id}/original`, `/documents/${original.document.id}`, `/properties/${home.id}/export`, `/records/${record.id}/history`])
    denied(await h.call(path, { token: buyer.token }));
  denied(await save(h, home, original.document.id, { token: buyer.token, version: record.version }));
  denied(await h.call(`/properties/${home.id}/access`, { token: buyer.token, method: 'POST', body: { role: 'owner', label: 'Spoof owner' } }));
});

integration('capability revocation applies immediately; display labels do not grant owner/admin roles', async t => {
  const h = await use(t), home = await property(h), buyer = await grant(h, home, 'buyer');
  ok(await h.call(`/properties/${home.id}`, { token: buyer.token }));
  ok(await h.call(`/properties/${home.id}/access/${buyer.id}/revoke`, { token: home.token, method: 'POST', body: {} }));
  denied(await h.call(`/properties/${home.id}`, { token: buyer.token }));
  denied(await h.call('/admin/settings', { token: buyer.token }));
  denied(await h.call(`/properties/${home.id}/access`, { token: home.token, method: 'POST', body: { role: 'owner', label: 'Administrator' } }));
  const contributor = await grant(h, home, 'contributor');
  const original = await upload(h, home, { token: contributor.token });
  denied(await h.call(`/documents/${original.document.id}/original`, { token: contributor.token }));
  denied(await h.call('/admin/documents', { token: contributor.token }));
  denied(await h.call('/admin/session', { token: contributor.token, method: 'POST', body: {} }));
});

integration('confirm false/true creates versioned draft/confirmed records and preserves the same original', async t => {
  const h = await use(t), home = await property(h), original = await upload(h, home);
  const values = await fields(home);
  values.review.status = 'confirmed'; values.confirmed_at = '1990-01-01T00:00:00Z';
  const draft = ok(await save(h, home, original.document.id, { values, confirm: false })).record;
  assert.equal(draft.version, 1); assert.equal(draft.status, 'draft');
  assert.equal(draft.fields.review.status, 'draft'); assert.equal(draft.fields.confirmed_at ?? null, null);
  values.service.summary = 'Manual correction survived refresh';
  const confirmed = ok(await save(h, home, original.document.id, { values, version: 1 })).record;
  assert.equal(confirmed.id, draft.id); assert.equal(confirmed.version, 2); assert.equal(confirmed.status, 'confirmed');
  assert.equal(confirmed.fields.review.status, 'confirmed');
  const confirmedAt = confirmed.fields.confirmed_at ?? confirmed.fields.review.confirmed_at;
  assert.notEqual(confirmedAt, '1990-01-01T00:00:00Z');
  assert.ok(Number.isFinite(Date.parse(confirmedAt)), 'Server must record actual confirmation time');
  const refreshed = ok(await h.call(`/properties/${home.id}`, { token: home.token }));
  assert.equal(refreshed.records.length, 1); assert.equal(refreshed.records[0].fields.service.summary, values.service.summary);
  const versions = ok(await h.call(`/records/${confirmed.id}/history`, { token: home.token })).versions;
  assert.deepEqual(versions.map(version => version.version).sort(), [1, 2]);
  const response = await h.raw(`/documents/${original.document.id}/original`, { token: home.token });
  assert.deepEqual(new Uint8Array(await response.arrayBuffer()), original.bytes);
});

integration('a document belonging to B cannot be saved under A, even by platform admin', async t => {
  const h = await use(t), a = await property(h, 'A'), b = await property(h, 'B'), original = await upload(h, b);
  for (const token of [a.token, FAKE_ADMIN])
    denied(await save(h, a, original.document.id, { token }), [400, 403, 404, 409]);
  assert.equal(h.DB.sqlite.prepare('SELECT COUNT(*) AS n FROM records').get().n, 0);
  assert.equal(h.DB.sqlite.prepare('SELECT property_id FROM documents WHERE id=?').get(original.document.id).property_id, b.id);
});

integration('concurrent edits of the same base version yield one version_conflict and no lost revision', async t => {
  const h = await use(t), home = await property(h), original = await upload(h, home);
  const first = ok(await save(h, home, original.document.id)).record;
  const responses = await Promise.all([
    save(h, home, original.document.id, { version: first.version, values: await fields(home, 'Concurrent edit A') }),
    save(h, home, original.document.id, { version: first.version, values: await fields(home, 'Concurrent edit B') }),
  ]);
  assert.equal(responses.filter(result => [200, 201].includes(result.status)).length, 1);
  const conflict = responses.find(result => result.status === 409);
  assert.ok(conflict, JSON.stringify(responses)); assert.equal(conflict.body.error.code, 'version_conflict');
  const current = ok(await h.call(`/properties/${home.id}`, { token: home.token })).records[0];
  assert.equal(current.version, first.version + 1);
  assert.equal(h.DB.sqlite.prepare('SELECT COUNT(*) AS n FROM record_versions WHERE record_id=?').get(first.id).n, 2);
});

integration('API configuration is admin-only, encrypted/redacted and cannot activate before its own successful test', async t => {
  const mock = await mockProvider(), h = await use(t, { fetcher: mock.fetcher }), home = await property(h);
  for (const path of ['/admin/settings', '/admin/activity']) denied(await h.call(path, { token: home.token }));
  const initial = ok(await h.call('/admin/settings'));
  const endpoint = initial.providers.find(provider => provider.id === 'openrouter').endpoint;
  const draft = ok(await h.call('/admin/settings', { method: 'PUT', body: {
    provider: 'openrouter', endpoint, model: initial.active.model, api_key: FAKE_NEW_KEY,
  } })).draft;
  assert.equal(draft.has_key, true); assertNoSecrets(draft, [FAKE_NEW_KEY, FAKE_ENV_KEY]);
  const stored = h.DB.sqlite.prepare('SELECT * FROM ai_configs WHERE id=?').get(draft.id);
  assert.ok(stored.key_cipher); assertNoSecrets(stored, [FAKE_NEW_KEY]);
  const beforeTest = await h.call('/admin/settings/activate', { method: 'POST', body: { config_id: draft.id } });
  assert.ok([400, 409].includes(beforeTest.status), JSON.stringify(beforeTest));
  assert.equal(mock.calls.length, 0);
  const tested = ok(await h.call('/admin/settings/test', { method: 'POST', body: { config_id: draft.id } }));
  assert.equal(tested.ok, true); assert.ok(mock.calls.length >= 1);
  assert.ok(mock.calls.every(call => call.authorization === `Bearer ${FAKE_NEW_KEY}`));
  const active = ok(await h.call('/admin/settings/activate', { method: 'POST', body: { config_id: draft.id } })).active;
  assert.equal(active.id, draft.id);
  const settings = ok(await h.call('/admin/settings'));
  assertNoSecrets(settings, [FAKE_NEW_KEY, FAKE_ENV_KEY]);
  assertNoSecrets(ok(await h.call('/admin/activity')), [FAKE_NEW_KEY, FAKE_ENV_KEY, FAKE_ADMIN, home.token]);
});

integration('changing provider host without a replacement key never reuses or sends the old key', async t => {
  const mock = await mockProvider(), h = await use(t, { fetcher: mock.fetcher });
  const initial = ok(await h.call('/admin/settings'));
  const endpoint = initial.providers.find(provider => provider.id === 'openrouter').endpoint;
  const originalDraft = ok(await h.call('/admin/settings', { method: 'PUT', body: {
    provider: 'openrouter', endpoint, model: initial.active.model, api_key: FAKE_NEW_KEY,
  } })).draft;
  ok(await h.call('/admin/settings/test', { method: 'POST', body: { config_id: originalDraft.id } }));
  ok(await h.call('/admin/settings/activate', { method: 'POST', body: { config_id: originalDraft.id } }));
  const previousCalls = mock.calls.length, changedEndpoint = 'https://api.openai.com/v1/chat/completions';
  const changed = await h.call('/admin/settings', { method: 'PUT', body: {
    provider: 'openai-compatible', endpoint: changedEndpoint, model: 'synthetic-compatible-model', api_key: '',
  } });
  if ([200, 201].includes(changed.status)) {
    assert.equal(changed.body.draft.has_key, false);
    const tested = await h.call('/admin/settings/test', { method: 'POST', body: { config_id: changed.body.draft.id } });
    assert.ok(tested.status >= 400 || tested.body.ok === false, JSON.stringify(tested));
  } else assert.ok([400, 409, 422].includes(changed.status), JSON.stringify(changed));
  assert.equal(mock.calls.length, previousCalls, 'Missing replacement key must fail before making an upstream call');
  const replacement = ok(await h.call('/admin/settings', { method: 'PUT', body: {
    provider: 'openai-compatible', endpoint: changedEndpoint, model: 'synthetic-compatible-model', api_key: FAKE_COMPAT_KEY,
  } })).draft;
  assert.ok([400, 409].includes((await h.call('/admin/settings/activate', { method: 'POST', body: { config_id: replacement.id } })).status));
  const tested = ok(await h.call('/admin/settings/test', { method: 'POST', body: { config_id: replacement.id } }));
  assert.equal(tested.ok, true); assert.equal(tested.pdf_supported, false);
  const changedHostCalls = mock.calls.slice(previousCalls);
  assert.ok(changedHostCalls.length >= 1);
  for (const call of changedHostCalls) {
    assert.equal(new URL(call.url).host, 'api.openai.com');
    assert.equal(call.authorization, `Bearer ${FAKE_COMPAT_KEY}`);
  }
});

integration('provider test failures are sanitized and cannot activate a failed configuration', async t => {
  const mock = await mockProvider(); mock.fail = true;
  const h = await use(t, { fetcher: mock.fetcher }), initial = ok(await h.call('/admin/settings'));
  const endpoint = initial.providers.find(provider => provider.id === 'openrouter').endpoint;
  const draft = ok(await h.call('/admin/settings', { method: 'PUT', body: {
    provider: 'openrouter', endpoint, model: initial.active.model, api_key: FAKE_NEW_KEY,
  } })).draft;
  const result = await h.call('/admin/settings/test', { method: 'POST', body: { config_id: draft.id } });
  assert.ok(result.status >= 400 || result.body.ok === false);
  assertNoSecrets(result.body, [FAKE_NEW_KEY, FAKE_ENV_KEY]);
  assert.ok([400, 409].includes((await h.call('/admin/settings/activate', { method: 'POST', body: { config_id: draft.id } })).status));
  assertNoSecrets(ok(await h.call('/admin/settings')), [FAKE_NEW_KEY, FAKE_ENV_KEY]);
  assertNoSecrets(ok(await h.call('/admin/activity')), [FAKE_NEW_KEY, FAKE_ENV_KEY]);
});

integration('actual schema 1.2 validates persisted/manual records and exports; actor/source metadata cannot be forged', async t => {
  const h = await use(t), home = await property(h), original = await upload(h, home);
  const values = await fields(home);
  values.property.uid = crypto.randomUUID();
  values.account = { id: 'forged-admin', display_name: 'Administrator', role: 'homeowner', is_demo: false };
  values.source = { name: 'forged.pdf', mime_type: 'application/pdf', mode: 'demo', sha256: 'f'.repeat(64) };
  const draft = ok(await save(h, home, original.document.id, { values, confirm: false })).record;
  await validateStoredRecord(draft.fields);
  assert.equal(draft.fields.account, null, 'Unauthenticated capability actor metadata belongs in server audit, not a pretend account');
  assert.equal(draft.fields.property.uid, home.id);
  assert.equal(draft.fields.source.name, 'receipt.png');
  assert.equal(draft.fields.source.sha256, createHash('sha256').update(original.bytes).digest('hex'));
  const confirmed = ok(await save(h, home, original.document.id, { values, version: draft.version })).record;
  await validateStoredRecord(confirmed.fields);
  const exported = ok(await h.call(`/properties/${home.id}/export`, { token: home.token }));
  for (const record of exported.records) await validateStoredRecord(record.fields);
  const audit = h.DB.sqlite.prepare('SELECT actor_id FROM record_versions WHERE record_id=?').all(confirmed.id);
  assert.ok(audit.every(row => row.actor_id !== 'forged-admin' && row.actor_id !== 'platform-admin'));
});

integration('unreadable and unrelated outcomes retain the cloud original and create no automatic record', async t => {
  for (const status of ['unreadable', 'unrelated']) {
    const mock = await mockProvider();
    mock.payload.status = status; mock.payload.relevance = status === 'unrelated' ? 'unrelated_service' : 'unknown';
    const h = await use(t, { fetcher: mock.fetcher }), home = await property(h, status), original = await upload(h, home);
    const result = ok(await h.call(`/documents/${original.document.id}/extract`, { token: home.token, method: 'POST', body: { locale: 'en-GB' } }));
    assert.equal(result.outcome, status);
    assert.equal(result.draft.service.summary, null);
    assert.equal(result.draft.amount.total, null);
    assert.deepEqual(result.draft.evidence, []);
    assert.equal(h.DB.sqlite.prepare('SELECT COUNT(*) AS n FROM records').get().n, 0);
    const stored = h.DB.sqlite.prepare('SELECT state,lease_id,lease_until FROM documents WHERE id=?').get(original.document.id);
    assert.equal(stored.state, status); assert.equal(stored.lease_id, null); assert.equal(stored.lease_until, null);
    const response = await h.raw(`/documents/${original.document.id}/original`, { token: home.token });
    assert.equal(response.status, 200); assert.deepEqual(new Uint8Array(await response.arrayBuffer()), original.bytes);
    const manual = ok(await save(h, home, original.document.id, { values: await fields(home, 'Explicit manual review after rejected extraction') })).record;
    await validateStoredRecord(manual.fields);
    assert.equal(manual.status, 'confirmed');
    assert.equal(h.DB.sqlite.prepare('SELECT COUNT(*) AS n FROM documents').get().n, 1);
  }
});

integration('upstream failure preserves original and sanitized error, releases extraction lease and allows retry', async t => {
  const mock = await mockProvider(); mock.fail = true; mock.failureStatus = 500;
  const h = await use(t, { fetcher: mock.fetcher }), home = await property(h), original = await upload(h, home);
  const failed = await h.call(`/documents/${original.document.id}/extract`, { token: home.token, method: 'POST', body: { locale: 'en-GB' } });
  assert.equal(failed.status, 502); assert.equal(failed.body.error.code, 'upstream_failed');
  assertNoSecrets(failed.body, [FAKE_NEW_KEY, FAKE_ENV_KEY]);
  let stored = h.DB.sqlite.prepare('SELECT * FROM documents WHERE id=?').get(original.document.id);
  assert.equal(stored.state, 'extraction_failed'); assert.equal(stored.last_error, 'upstream_failed');
  assert.equal(stored.lease_id, null); assert.equal(stored.lease_until, null);
  assert.deepEqual(h.BUCKET.objects.get(stored.storage_key).bytes, original.bytes);
  assert.equal(h.DB.sqlite.prepare('SELECT COUNT(*) AS n FROM records').get().n, 0);
  mock.fail = false;
  const retried = ok(await h.call(`/documents/${stored.id}/extract`, { token: home.token, method: 'POST', body: { locale: 'en-GB' } }));
  assert.equal(retried.outcome, 'partial'); assert.equal(retried.base_version, 0);
  stored = h.DB.sqlite.prepare('SELECT * FROM documents WHERE id=?').get(stored.id);
  assert.equal(stored.last_error, null); assert.equal(stored.lease_id, null);
  assert.equal(mock.calls.length, 2);
});

integration('sequential and racing duplicate uploads create one document per property and clean up losing objects', async t => {
  const h = await use(t), a = await property(h, 'A'), b = await property(h, 'B'), c = await property(h, 'C');
  const uploadResult = home => {
    const body = new FormData(); body.append('file', new File([PNG], 'same.png', { type: 'image/png' }));
    return h.call(`/properties/${home.id}/documents`, { token: home.token, method: 'POST', body });
  };
  ok(await uploadResult(a));
  const duplicate = await uploadResult(a);
  assert.equal(duplicate.status, 409); assert.equal(duplicate.body.error.code, 'duplicate_document');
  ok(await uploadResult(b)); // Same bytes in another authorized property do not leak existence or reuse its permission.
  const racing = await Promise.all([uploadResult(c), uploadResult(c)]);
  assert.equal(racing.filter(result => [200, 201].includes(result.status)).length, 1);
  assert.equal(racing.filter(result => result.status === 409 && result.body.error.code === 'duplicate_document').length, 1);
  assert.equal(h.DB.sqlite.prepare('SELECT COUNT(*) AS n FROM documents').get().n, 3);
  assert.equal(h.BUCKET.objects.size, 3);
});

integration('one extraction lease prevents concurrent duplicate provider calls; re-extraction never overwrites a confirmed record', async t => {
  const mock = await mockProvider(); let release, entered;
  const gate = new Promise(resolve => { release = resolve; }), started = new Promise(resolve => { entered = resolve; });
  const h = await use(t, { fetcher: async (...args) => { entered(); await gate; return mock.fetcher(...args); } });
  const home = await property(h), original = await upload(h, home);
  const pending = h.call(`/documents/${original.document.id}/extract`, { token: home.token, method: 'POST', body: {} });
  await started;
  try {
    const duplicate = await h.call(`/documents/${original.document.id}/extract`, { token: home.token, method: 'POST', body: {} });
    assert.equal(duplicate.status, 409); assert.equal(duplicate.body.error.code, 'extraction_in_progress');
    assert.equal(h.DB.sqlite.prepare('SELECT COUNT(*) AS n FROM usage_events').get().n, 1);
  } finally { release(); }
  ok(await pending); assert.equal(mock.calls.length, 1);
  const confirmed = ok(await save(h, home, original.document.id, { values: await fields(home, 'Owner correction is authoritative') })).record;
  await validateStoredRecord(confirmed.fields);
  mock.payload.service.summary = 'New proposal from explicit retry';
  const retried = ok(await h.call(`/documents/${original.document.id}/extract`, { token: home.token, method: 'POST', body: {} }));
  assert.equal(retried.base_version, confirmed.version); assert.equal(retried.record_id, confirmed.id);
  const current = ok(await h.call(`/properties/${home.id}`, { token: home.token })).records[0];
  assert.equal(current.version, confirmed.version); assert.equal(current.status, 'confirmed');
  assert.equal(current.fields.service.summary, 'Owner correction is authoritative');
  assert.equal(mock.calls.length, 2, 'An explicit subsequent retry is a separate call, not a silent cache result');
});

integration('daily limit counts in-flight reservations atomically across documents and resets with the usage day', async t => {
  const mock = await mockProvider(); let release, entered;
  const gate = new Promise(resolve => { release = resolve; }), started = new Promise(resolve => { entered = resolve; });
  const h = await use(t, { fetcher: async (...args) => { entered(); await gate; return mock.fetcher(...args); } });
  h.env.DOMIC_DAILY_AI_CALLS = '1';
  const home = await property(h), a = await upload(h, home, { marker: 'daily-A' }), b = await upload(h, home, { marker: 'daily-B' });
  const pending = h.call(`/documents/${a.document.id}/extract`, { token: home.token, method: 'POST', body: {} });
  await started;
  try {
    const limited = await h.call(`/documents/${b.document.id}/extract`, { token: home.token, method: 'POST', body: {} });
    assert.equal(limited.status, 429); assert.equal(limited.body.error.code, 'daily_limit_reached');
    assert.equal(h.DB.sqlite.prepare('SELECT COUNT(*) AS n FROM usage_events').get().n, 1);
  } finally { release(); }
  ok(await pending); assert.equal(mock.calls.length, 1);
  const limitedAgain = await h.call(`/documents/${b.document.id}/extract`, { token: home.token, method: 'POST', body: {} });
  assert.equal(limitedAgain.status, 429); assert.equal(mock.calls.length, 1);
  const row = h.DB.sqlite.prepare('SELECT state,lease_id FROM documents WHERE id=?').get(b.document.id);
  assert.equal(row.lease_id, null, 'Quota failure must release document lease');
  // Move only the isolated test usage row to a prior day; production clock/state are untouched.
  h.DB.sqlite.prepare("UPDATE usage_events SET day='2000-01-01'").run();
  ok(await h.call(`/documents/${b.document.id}/extract`, { token: home.token, method: 'POST', body: {} }));
  assert.equal(mock.calls.length, 2);
});

integration('failed provider attempts still consume the daily reservation and do not permit unlimited retries', async t => {
  const mock = await mockProvider(); mock.fail = true; mock.failureStatus = 500;
  const h = await use(t, { fetcher: mock.fetcher }); h.env.DOMIC_DAILY_AI_CALLS = '1';
  const home = await property(h), a = await upload(h, home, { marker: 'failure-A' }), b = await upload(h, home, { marker: 'failure-B' });
  const failed = await h.call(`/documents/${a.document.id}/extract`, { token: home.token, method: 'POST', body: {} });
  assert.equal(failed.status, 502); assert.equal(mock.calls.length, 1);
  assert.equal(h.DB.sqlite.prepare('SELECT state FROM usage_events').get().state, 'failed');
  const limited = await h.call(`/documents/${b.document.id}/extract`, { token: home.token, method: 'POST', body: {} });
  assert.equal(limited.status, 429); assert.equal(limited.body.error.code, 'daily_limit_reached');
  assert.equal(mock.calls.length, 1);
  assert.equal(h.BUCKET.objects.size, 2);
});

integration('identical extraction attempt is replayed without a second paid request; normalized uncertainty stays partial', async t=>{
 const mock=await mockProvider();mock.payload.status='readable';mock.payload.relevance='unknown';const h=await use(t,{fetcher:mock.fetcher}),home=await property(h),doc=await upload(h,home);const body={request_id:crypto.randomUUID()};
 const a=ok(await h.call(`/documents/${doc.document.id}/extract`,{method:'POST',token:home.token,body}));const b=ok(await h.call(`/documents/${doc.document.id}/extract`,{method:'POST',token:home.token,body}));assert.deepEqual(a,b);assert.equal(mock.calls.length,1);assert.equal(a.outcome,'partial');assert.equal(a.draft.extraction.status,'uncertain');assert.equal(a.draft.extraction.request_id,'fixture-no-paid-call');
});
integration('audit outage does not turn an already persisted record into a failed save', async t=>{
 const h=await use(t),home=await property(h),doc=await upload(h,home);h.DB.sqlite.exec('DROP TABLE audit_events');const result=ok(await save(h,home,doc.document.id));assert.equal(result.record.status,'confirmed');assert.equal(h.DB.sqlite.prepare('SELECT count(*) n FROM record_versions').get().n,1);
});

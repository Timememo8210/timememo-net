import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFile} from 'node:fs/promises';
const require=createRequire(import.meta.url);
const {JSDOM}=require('jsdom');
const base=new URL('../public/',import.meta.url);
const {blankRecord}=await import(new URL('record-core.js',base));
const json=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{'content-type':'application/json'}});
const property={id:'home-1',passport_id:'DHP-0001',name:'Fictional Orchard Home',address:'22 Fictional Orchard Close',owner_label:'Test owner',record_count:0};
async function setup(file,url){const dom=new JSDOM(await readFile(new URL(file,base),'utf8'),{url});for(const name of ['window','document','location','history','sessionStorage'])globalThis[name]=name==='window'?dom.window:dom.window[name];dom.window.HTMLDialogElement.prototype.showModal=function(){this.open=true;};dom.window.HTMLDialogElement.prototype.close=function(){this.open=false;};dom.window.confirm=()=>true;dom.window.HTMLElement.prototype.scrollIntoView=function(){};Object.defineProperty(globalThis,'navigator',{configurable:true,value:{clipboard:{writeText:async value=>{globalThis.lastCopied=value;}}}});return dom;}
const $=selector=>document.querySelector(selector);
function input(id,value){const element=document.getElementById(id);element.value=value;element.dispatchEvent(new window.Event('input',{bubbles:true}));}
function confirm(){ $('#confirm-check').checked=true;$('#confirm-check').onchange();return $('#confirm-save').onclick(); }
let testSerial=0;
async function app(name){
 if(name==='workspace.js'&&process.env.DOMIC_WORKSPACE_SOURCE){let source=await readFile(process.env.DOMIC_WORKSPACE_SOURCE,'utf8');source=source.replace(/from '\.\/([^']+)'/g,(_,path)=>`from ${JSON.stringify(new URL(path,base).href)}`);await import('data:text/javascript;base64,'+Buffer.from(source+'\n// test '+(++testSerial)).toString('base64'));return;}
 await import(new URL(name+'?test='+(++testSerial),base));
}

test('owner cloud pipeline retains original before review, saves to permanent property only after checkbox, supports editing and protects version conflicts',async()=>{
 const dom=await setup('workspace.html','https://unit.test/workspace/?property=home-1#access=owner-capability');
 const draft=blankRecord();draft.property.uid='wrong-model-property';draft.service.summary='Repair kitchen tap';draft.amount.total=264;draft.amount.currency='GBP';draft.provider.name='Fictional plumber';
 let storedRecord=null,uploaded=null,saveCalls=0,conflict=false;const calls=[];
 globalThis.fetch=async(url,options)=>{calls.push({url,options});assert.equal(options.headers.Authorization,'Bearer owner-capability',url.endsWith('/status')?'public status ignores token':'correct scoped token');return json({});};
 globalThis.fetch=async(url,options)=>{
  calls.push({url,options});if(url.endsWith('/status'))return json({storage_ready:true,max_file_bytes:6291456});assert.equal(options.headers.Authorization,'Bearer owner-capability');
  if(url==='/api/cloud/properties/home-1')return json({property,role:'owner',records:storedRecord?[storedRecord]:[],documents:uploaded?[uploaded]:[],access:[]});
  if(url.endsWith('/documents')&&options.method==='POST'){uploaded={id:'doc-1',name:'fictional.pdf',mime_type:'application/pdf',state:'uploaded'};return json({document:uploaded});}
  if(url.endsWith('/documents/doc-1/extract'))return json({document:uploaded,draft,outcome:'partial',model:'unit-model',base_version:storedRecord?.version||0,record_id:storedRecord?.id||null});
  if(url.endsWith('/documents/doc-1/original'))return new Response('%PDF-1.4\n%%EOF',{headers:{'content-type':'application/pdf'}});
  if(url.endsWith('/documents/doc-1'))return json({document:uploaded,draft,record:storedRecord});
  if(url.endsWith('/records')&&options.method==='POST'){saveCalls++;const payload=JSON.parse(options.body);assert.equal(payload.confirm,true);assert.equal(payload.fields.property.uid,'home-1');assert.equal(payload.fields.property.id,property.name);if(conflict)return json({error:{code:'version_conflict'}},409);storedRecord={id:'record-1',document_id:'doc-1',version:(storedRecord?.version||0)+1,status:'confirmed',fields:payload.fields};uploaded.record_id=storedRecord.id;return json({record:storedRecord});}
  throw Error('Unexpected API path '+url);
 };
 await app('workspace.js');assert.equal(location.hash,'');assert.equal(sessionStorage.getItem('domic-property-access-home-1'),'owner-capability');assert.equal($('#add-document').hidden,false);
 $('#add-document').onclick();$('#document-file').onchange({target:{files:[new File(['%PDF-1.4\n%%EOF'],'fictional.pdf',{type:'application/pdf'})]}});await $('#read-document').onclick();
 assert.ok(uploaded);assert.equal(saveCalls,0);assert.equal($('#review-stage').hidden,false);assert.equal($('#review-form').hidden,false);assert.equal(document.getElementById('field-amount-total').value,'264');
 input('field-amount-total','265');$('#review-form').onsubmit({preventDefault(){}});assert.equal($('#confirm-dialog').open,true);assert.equal($('#confirm-save').disabled,true);await $('#confirm-save').onclick();assert.equal(saveCalls,0);await confirm();assert.equal(saveCalls,1);assert.equal(storedRecord.fields.amount.total,265);assert.equal($('#intake-dialog').open,false);
 await $('[data-edit="record-1"]').onclick();assert.equal(document.getElementById('field-amount-total').value,'265');input('field-amount-total','266');$('#review-form').onsubmit({preventDefault(){}});assert.equal($('#confirm-save').disabled,true);conflict=true;await confirm();assert.match($('#confirm-message').textContent,/changed since/);assert.equal(storedRecord.fields.amount.total,265);assert.equal($('#confirm-dialog').open,true);assert.ok($('#reload-latest'));assert.equal(saveCalls,2);
 storedRecord.version=2;storedRecord.fields.amount.total=300;await $('#reload-latest').onclick();assert.equal(document.getElementById('field-amount-total').value,'300');assert.equal($('#confirm-dialog').open,false);assert.equal(calls.some(call=>call.url.includes('/original')),true);dom.window.close();
});

test('buyer capability renders only shared history and never requests stored originals',async()=>{
 const dom=await setup('workspace.html','https://unit.test/workspace/?property=home-1#access=buyer-capability');const calls=[];
 globalThis.fetch=async(url)=>{calls.push(url);if(url.endsWith('/status'))return json({storage_ready:true});if(url.endsWith('/properties/home-1'))return json({property,role:'buyer',records:[{id:'shared-1',status:'confirmed',fields:{service:{summary:'Boiler inspection',date:null},document:{type:'estimate'},amount:{total:90,currency:'GBP'}}}]});throw Error('Buyer attempted private endpoint '+url);};
 await app('workspace.js');assert.equal($('#add-document').hidden,true);assert.equal($('#property-sharing').hidden,true);assert.equal($('#pending-documents').hidden,true);assert.equal(document.querySelectorAll('[data-original],[data-edit]').length,0);$('#add-document').onclick();assert.equal($('#intake-dialog').open,false);await $('[data-record="shared-1"]').onclick();assert.equal($('#record-original').hidden,true);assert.equal($('#edit-record').hidden,true);assert.match($('#history-list').textContent,/Estimate/);assert.equal(calls.some(url=>url.includes('/documents/')),false);dom.window.close();
});

test('management unlock, immutable configuration save-test-enable, no key echo and one-time owner link',async()=>{
 const dom=await setup('admin.html','https://unit.test/admin/');let draft=null,active={id:'active-1',provider:'openrouter',endpoint:'https://provider.test/v1',model:'old-model',has_key:true};let testOK=true,activations=0,creates=0;const calls=[];
 const providers=[{id:'openrouter',label:'OpenRouter',endpoint:'https://provider.test/v1'},{id:'openai-compatible',label:'Compatible',endpoint:'https://other.test/v1'}];
 globalThis.fetch=async(url,options)=>{calls.push({url,options});assert.equal(options.headers.Authorization,'Bearer management-code');if(url.endsWith('/admin/session'))return json({role:'admin'});if(url.endsWith('/admin/settings')&&options.method==='GET')return json({active,draft,providers});if(url.endsWith('/properties')&&options.method==='GET')return json({properties:[]});if(url.endsWith('/admin/documents'))return json({documents:[]});if(url.endsWith('/admin/activity'))return json({events:[],usage:{calls:0,total_cost:0}});if(url.endsWith('/admin/settings')&&options.method==='PUT'){const data=JSON.parse(options.body);draft={id:'config-'+calls.length,provider:data.provider,endpoint:data.endpoint,model:data.model,has_key:true,test_ok:false};return json({draft});}if(url.endsWith('/admin/settings/test')){assert.equal(JSON.parse(options.body).config_id,draft.id);return json({ok:testOK,model:draft.model,elapsed_ms:30,pdf_supported:true,tested_at:'2026-09-12T12:00:00Z'});}if(url.endsWith('/admin/settings/activate')){activations++;assert.equal(JSON.parse(options.body).config_id,draft.id);active={...draft};return json({active});}if(url.endsWith('/properties')&&options.method==='POST'){creates++;const payload=JSON.parse(options.body);assert.ok(payload.request_id);return json({property:{...property,id:'new-home'},access_url:'/workspace/?property=new-home#access=issued-owner-capability'});}throw Error('Unexpected management API '+url);};
 await app('admin.js');input('admin-access-code','management-code');await $('#admin-access-form').onsubmit({preventDefault(){}});assert.equal($('#admin-access-code').value,'');assert.equal($('#admin-content').hidden,false);assert.equal($('#api-key').value,'');assert.equal($('#test-reader-config').disabled,true);assert.equal($('#enable-reader').disabled,true);
 input('model-name','new-model');input('api-key','synthetic-secret-for-test');await $('#reader-config-form').onsubmit({preventDefault(){}});assert.equal($('#api-key').value,'');assert.equal($('#test-reader-config').disabled,false);assert.equal($('#enable-reader').disabled,true);await $('#test-reader-config').onclick();assert.equal($('#enable-reader').disabled,false);input('model-name','changed-after-test');assert.equal($('#enable-reader').disabled,true);await $('#enable-reader').onclick();assert.equal(activations,0);await $('#reader-config-form').onsubmit({preventDefault(){}});await $('#test-reader-config').onclick();await $('#enable-reader').onclick();assert.equal(activations,1);
 $('#create-property').onclick();input('new-property-name','New fictional home');input('new-property-address','1 Invented Road');await $('#create-property-form').onsubmit({preventDefault(){}});assert.equal(creates,1);assert.equal($('#new-owner-result').hidden,false);assert.doesNotMatch(document.body.textContent,/issued-owner-capability|synthetic-secret-for-test|management-code/);await $('#copy-new-owner-link').onclick();assert.match(globalThis.lastCopied,/issued-owner-capability/);$('#lock-admin').onclick();assert.equal(sessionStorage.getItem('domic-cloud-admin'),null);assert.equal($('#admin-content').hidden,true);dom.window.close();
});

for(const scenario of [
 {name:'stored unreadable outcome',state:'unreadable',extracted:'no_text',recovery:'No usable receipt details'},
 {name:'stored unrelated outcome',state:'unrelated',extracted:'unrelated',recovery:'unrelated to home maintenance'},
 {name:'draft no_text with legacy document state',state:'uploaded',extracted:'no_text',recovery:'No usable receipt details'},
 {name:'draft unrelated with legacy document state',state:'uploaded',extracted:'unrelated',recovery:'unrelated to home maintenance'},
 {name:'extraction failure with no draft',state:'extraction_failed',noDraft:true,lastError:'timeout',recovery:'request took too long'},
 {name:'extraction failure with an older readable draft',state:'extraction_failed',extracted:'review',lastError:'rate_limited',recovery:'Too many requests'},
 {name:'partial draft keeps partial review guidance',state:'partial',extracted:'partial',partial:true},
 {name:'confirmed manual record overrides old unreadable analysis',state:'unreadable',extracted:'no_text',savedStatus:'confirmed'},
 {name:'explicitly saved draft overrides old unrelated analysis',state:'unrelated',extracted:'unrelated',savedStatus:'draft'},
 {name:'saved record remains editable after a later extraction failure',state:'extraction_failed',noDraft:true,lastError:'timeout',savedStatus:'confirmed'},
]){
 test('reopen recovery: '+scenario.name,async()=>{
  const dom=await setup('workspace.html','https://unit.test/workspace/?property=home-1#access=owner-capability');
  const draft=scenario.noDraft?null:blankRecord();if(draft){draft.extraction={status:scenario.extracted};draft.service.summary='Unreviewed extraction text';}
  const corrected=blankRecord();corrected.service.summary='Human-confirmed boiler inspection';corrected.property.id=property.name;corrected.property.uid=property.id;
  const record=scenario.savedStatus?{id:'saved-record',document_id:'reopened-doc',version:3,status:scenario.savedStatus,fields:corrected}:null;
  const document={id:'reopened-doc',name:'reopened.pdf',mime_type:'application/pdf',state:scenario.state,last_error:scenario.lastError||null,record_id:record?.id||null};
  const calls=[];
  globalThis.fetch=async(url,options)=>{calls.push({url,method:options.method});assert.equal(options.method,'GET','Opening or choosing recovery must not write, extract, or confirm automatically');if(url.endsWith('/status'))return json({storage_ready:true});if(url.endsWith('/properties/home-1'))return json({property,role:'owner',records:record?[record]:[],documents:[document],access:[]});if(url.endsWith('/documents/reopened-doc/original'))return new Response('%PDF-1.4\n%%EOF',{headers:{'content-type':'application/pdf'}});if(url.endsWith('/documents/reopened-doc'))return json({document,draft,record});throw Error('Unexpected reopen request '+url);};
  await app('workspace.js');
  const opener=record?$('[data-edit="saved-record"]'):$('[data-resume="reopened-doc"]');await opener.onclick();
  assert.equal($('#review-stage').hidden,false);
  assert.equal($('#confirm-dialog').open,false);
  if(scenario.recovery){
   assert.equal($('#review-form').hidden,true,'Invalid/unreadable results must not silently open editable review');
   assert.match($('#reading-outcome').textContent,new RegExp(scenario.recovery,'i'));
   assert.ok($('#retry-extraction'),'retry is available');assert.ok($('#replace-unreadable'),'replacement is available');assert.ok($('#manual-entry'),'manual entry remains an explicit user choice');
   assert.equal($('#reading-outcome').textContent.includes('Read stored original again'),false,'Do not add a second retry action that reads absent editor fields');
   await $('#confirm-save').onclick();assert.equal(calls.every(call=>call.method==='GET'),true);
   $('#manual-entry').onclick();assert.equal($('#review-form').hidden,false);assert.equal(documentGet('field-service-summary').value,'','Manual recovery clears unreviewed extracted facts');
  }else{
   assert.equal($('#review-form').hidden,false);assert.equal($('#retry-extraction'),null);assert.equal($('#manual-entry'),null);
   if(scenario.savedStatus)assert.equal(documentGet('field-service-summary').value,'Human-confirmed boiler inspection');
   if(scenario.partial)assert.match($('#reading-outcome').textContent,/Some details need your help/);
  }
  assert.equal(calls.some(call=>call.url.includes('/extract')||call.url.endsWith('/records')),false);
  dom.window.close();
 });
}
function documentGet(id){return globalThis.document.getElementById(id);}

import { readFile, readdir } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';
import assert from 'node:assert/strict';
import { SqliteD1, MemoryR2 } from './adapters.mjs';

const siblingRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..');
export const SITE_ROOT = process.env.DOMIC_SITE_ROOT || (existsSync(join(siblingRoot, 'cloud', 'router.js'))
  ? siblingRoot : '/Users/m5pro/Codex_m5pro/domic-ai-service');
export const ROUTER_PATH = join(SITE_ROOT, 'cloud', 'router.js');
export const HAS_ROUTER = existsSync(ROUTER_PATH);
export const ORIGIN = 'https://domic-integration.example.test';
export const FAKE_ADMIN = 'test_admin_only_abcdefghijklmnopqrstuvwxyz0123456789';
export const FAKE_ENV_KEY = 'test_openrouter_env_only_abcdefghijklmnopqrstuvwxyz0123456789';
export const FAKE_NEW_KEY = 'test_openrouter_draft_only_abcdefghijklmnopqrstuvwxyz9876543210';
export const FAKE_COMPAT_KEY = 'test_compatible_only_abcdefghijklmnopqrstuvwxyz5432109876';
export const PNG = Uint8Array.from(Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jFz0AAAAASUVORK5CYII=', 'base64'));
export const noNetwork = async () => { throw new Error('TEST BLOCKED: unexpected real network request'); };

let recordValidator;
export async function validateStoredRecord(record) {
  if (!recordValidator) {
    const prototypeRoot = process.env.DOMIC_SCHEMA_PACKAGE_ROOT || SITE_ROOT;
    const schemaPath = process.env.DOMIC_RECORD_SCHEMA || join(prototypeRoot, 'docs', 'receipt.schema.json');
    const require = createRequire(pathToFileURL(join(prototypeRoot, 'package.json')));
    const { default: Ajv } = await import(pathToFileURL(require.resolve('ajv/dist/2020.js')));
    const { default: addFormats } = await import(pathToFileURL(require.resolve('ajv-formats')));
    const ajv = new Ajv({ strict: false, allErrors: true }); addFormats(ajv);
    recordValidator = ajv.compile(JSON.parse(await readFile(schemaPath, 'utf8')));
  }
  assert.equal(record.schema_version, '1.2');
  assert.ok(recordValidator(record), JSON.stringify(recordValidator.errors));
}

export async function initializeDatabase(database) {
  const migrations = (await readdir(join(SITE_ROOT, 'drizzle'))).filter(name => name.endsWith('.sql')).sort();
  assert.ok(migrations.length, 'Expected real drizzle SQL migrations');
  for (const name of migrations) {
    const sql = (await readFile(join(SITE_ROOT, 'drizzle', name), 'utf8')).replace(/-->\s*statement-breakpoint/g, '\n');
    await database.exec(sql);
  }
  return migrations;
}

export async function createHarness({ fetcher = noNetwork, legacyService } = {}) {
  const DB = new SqliteD1(), BUCKET = new MemoryR2();
  const migrations = await initializeDatabase(DB);
  const env = { DB, BUCKET, DOMIC_ADMIN_TOKEN: FAKE_ADMIN,
    DOMIC_SETTINGS_KEY: Buffer.alloc(32, 41).toString('base64'), OPENROUTER_API_KEY: FAKE_ENV_KEY,
    DOMIC_PILOT_TOKEN: 'test_legacy_pilot_only_abcdefghijklmnopqrstuvwxyz0123456789',
    DOMIC_ALLOWED_ORIGINS: ORIGIN };
  const { createWorkspace } = await import(pathToFileURL(ROUTER_PATH));
  assert.equal(typeof createWorkspace, 'function', 'Router must export createWorkspace');
  const testImage = new Uint8Array(await readFile(join(SITE_ROOT, 'public', 'test-receipt.png')));
  assert.deepEqual([...testImage.slice(0, 8)], [137, 80, 78, 71, 13, 10, 26, 10], 'Read the real fixed test PNG locally; never fetch it');
  const api = createWorkspace({ fetcher, testImage, ...(legacyService ? { legacyService } : {}) });
  return { api, env, DB, BUCKET, migrations, testImage, close: () => DB.close(),
    async raw(path, { token = FAKE_ADMIN, method = 'GET', body, headers = {} } = {}) {
      const requestHeaders = new Headers(headers);
      if (token) requestHeaders.set('Authorization', `Bearer ${token}`);
      let payload = body;
      if (body !== undefined && !(body instanceof FormData) && !(body instanceof Uint8Array) && typeof body !== 'string') {
        requestHeaders.set('Content-Type', 'application/json'); payload = JSON.stringify(body);
      }
      return api.fetch(new Request(ORIGIN + '/api/cloud' + path, { method, headers: requestHeaders, ...(payload === undefined ? {} : { body: payload }) }), env);
    },
    async call(path, options) {
      const response = await this.raw(path, options), text = await response.text();
      let body;
      try { body = text ? JSON.parse(text) : null; } catch { body = text; }
      return { status: response.status, body, headers: response.headers };
    },
  };
}

export function ok(result, statuses = [200, 201]) {
  assert.ok(statuses.includes(result.status), `Expected success; received ${result.status}: ${JSON.stringify(result.body)}`);
  return result.body;
}
export function denied(result, statuses = [401, 403, 404]) {
  assert.ok(statuses.includes(result.status), `Expected access denial; received ${result.status}: ${JSON.stringify(result.body)}`);
  assert.equal(typeof result.body?.error?.code, 'string', 'Denials use the JSON error envelope');
}
export function tokenFrom(url) {
  const parsed = new URL(url, ORIGIN), token = new URLSearchParams(parsed.hash.slice(1)).get('access');
  assert.match(token || '', /^[A-Za-z0-9_-]{40,}$/, 'Access links contain a high-entropy opaque fragment token');
  assert.equal(parsed.searchParams.has('access'), false, 'Do not put raw capability in a query string');
  return token;
}
export async function property(h, suffix = 'A') {
  const body = ok(await h.call('/properties', { method: 'POST', body: {
    name: `House ${suffix}`, address: `${suffix} Fictional Test Lane`, owner_label: `Owner ${suffix}`, request_id: crypto.randomUUID(),
  } }));
  assert.match(body.property.id, /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i);
  return { ...body.property, token: tokenFrom(body.access_url), access_url: body.access_url };
}
export async function grant(h, home, role, token = home.token) {
  const data = ok(await h.call(`/properties/${home.id}/access`, { method: 'POST', token, body: { role, label: `${role} test label` } }));
  return { ...data, token: tokenFrom(data.access_url) };
}
export async function upload(h, home, { token = home.token, marker = '', name = 'receipt.png' } = {}) {
  const bytes = new Uint8Array([...PNG, ...new TextEncoder().encode(marker)]), form = new FormData();
  form.append('file', new File([bytes], name, { type: 'image/png' }));
  form.append('uploader_label', 'Display-only test uploader');
  const result = ok(await h.call(`/properties/${home.id}/documents`, { token, method: 'POST', body: form }));
  return { document: result.document, bytes };
}
export async function fields(home, summary = 'Repair leaking kitchen tap') {
  const { blankRecord } = await import(pathToFileURL(join(SITE_ROOT, 'shared', 'core.js')));
  const data = blankRecord();
  data.property = { id: home.name, uid: home.id, service_address: home.address };
  data.service = { date: '2026-09-12', category: 'plumbing', change_type: 'repair', summary, location: 'Kitchen', completion_status: 'completed' };
  data.document.type = 'receipt';
  data.provider.name = data.provider.organization_name = 'Synthetic Test Plumbing';
  data.amount = { total: 125, currency: 'GBP', payment_status: 'paid' };
  data.notes = 'PRIVATE OWNER NOTE: never include in buyer history';
  return data;
}
export async function save(h, home, documentId, { token = home.token, confirm = true, version = 0, values } = {}) {
  return h.call(`/properties/${home.id}/records`, { method: 'POST', token,
    body: { document_id: documentId, fields: values || await fields(home), confirm, base_version: version } });
}
export function assertNoKeys(value, forbidden, path = '$') {
  if (!value || typeof value !== 'object') return;
  for (const [key, nested] of Object.entries(value)) {
    assert.ok(!forbidden.includes(key), `Forbidden field ${path}.${key}`);
    assertNoKeys(nested, forbidden, `${path}.${key}`);
  }
}
export function assertNoSecrets(value, secrets) {
  const text = typeof value === 'string' ? value : JSON.stringify(value);
  for (const secret of secrets) assert.ok(!text.includes(secret), 'Raw test secret leaked in response or persistence');
}

export async function mockProvider() {
  const { AI_EXTRACTION_SCHEMA } = await import(pathToFileURL(join(SITE_ROOT, 'shared', 'ai-contract.js')));
  const empty = schema => schema.enum ? (schema.enum.includes('unknown') ? 'unknown' : schema.enum[0])
    : Array.isArray(schema.type) && schema.type.includes('null') ? null
    : schema.type === 'object' ? Object.fromEntries(Object.entries(schema.properties).map(([key, value]) => [key, empty(value)]))
    : schema.type === 'array' ? [] : schema.type === 'integer' ? 1 : '';
  const payload = empty(AI_EXTRACTION_SCHEMA);
  payload.status = 'partial'; payload.relevance = 'home_service';
  payload.service.summary = 'Repair kitchen tap';
  payload.amount.total = 264; payload.amount.currency = 'GBP';
  payload.evidence = [
    { field: 'service.summary', page: 1, quote: 'Repair kitchen tap' },
    { field: 'amount.total', page: 1, quote: 'TOTAL PAID GBP 264.00' },
    { field: 'amount.currency', page: 1, quote: 'TOTAL PAID GBP 264.00' },
  ];
  const calls = [];
  const mock = { calls, fail: false, failureStatus: 401, payload,
    async fetcher(input, options = {}) {
      const request = input instanceof Request ? input : new Request(input, options);
      const sent = await request.clone().text();
      calls.push({ url: request.url, authorization: request.headers.get('Authorization'), body: sent ? JSON.parse(sent) : null });
      if (mock.fail) return Response.json({ error: { message: FAKE_NEW_KEY + ' provider rejected request' } }, { status: mock.failureStatus });
      return Response.json({ id: 'fixture-no-paid-call', choices: [{ finish_reason: 'stop', message: { content: JSON.stringify(mock.payload) } }],
        usage: { prompt_tokens: 20, completion_tokens: 15, total_tokens: 35, cost: 0 } });
    },
  };
  return mock;
}

import test from 'node:test';
import assert from 'node:assert/strict';
import { createService, buildModelRequest, matchesSchema, providerSchema, readBounded, MAX_FILE_BYTES, DEFAULT_MODEL } from '../worker.js';
import { AI_EXTRACTION_SCHEMA } from '../shared/ai-contract.js';

const env = { OPENROUTER_API_KEY: 'test-upstream-secret', DOMIC_PILOT_TOKEN: 'test-pilot-code-longer-than-24-characters' };
const png = new Uint8Array([137,80,78,71,13,10,26,10,0]);
const pdf = new TextEncoder().encode('%PDF-1.7\nfixture');
function empty(schema = AI_EXTRACTION_SCHEMA) {
  if (schema.enum) return schema.enum.includes('unknown') ? 'unknown' : schema.enum[0];
  if (Array.isArray(schema.type) && schema.type.includes('null')) return null;
  if (schema.type === 'object') return Object.fromEntries(Object.entries(schema.properties).map(([k,v]) => [k,empty(v)]));
  if (schema.type === 'array') return [];
  return schema.type === 'integer' ? 1 : '';
}
function result(patch = {}) { return { ...empty(), status: 'partial', relevance: 'home_service', ...patch }; }
function upstream(payload = result(), options = {}) {
  return Response.json({ id: 'test-request', choices: [{ finish_reason: 'stop', message: { content: JSON.stringify(payload) } }], usage: { prompt_tokens: 1000, completion_tokens: 300, total_tokens: 1300, completion_tokens_details: { reasoning_tokens: 20 }, cost: .0007 }, ...options });
}
function request({ path = '/api/extract', token = env.DOMIC_PILOT_TOKEN, origin = 'https://timememo.net', bytes = png, type = 'image/png', model, headers = {} } = {}) {
  const body = new FormData(); body.append('file', new File([bytes], type === 'application/pdf' ? 'receipt.pdf' : 'receipt.png', { type })); body.append('locale', 'en-GB');
  if (model !== undefined) body.append('model', model);
  return new Request(`https://service.example${path}`, { method: 'POST', headers: { ...(token ? {Authorization: `Bearer ${token}`} : {}), ...(origin ? { Origin: origin } : {}), ...headers }, ...(path === '/api/extract' ? {body} : {}) });
}
async function expectError(response, status, code) { assert.equal(response.status, status); assert.deepEqual(await response.json(), { error: { code } }); }

test('health/session disclose no key and never invoke the model', async () => {
  const api = createService({ fetcher: () => { throw Error('unexpected paid request'); } });
  const health = await api.fetch(new Request('https://service.example/api/health'), env);
  assert.equal((await health.json()).configured, true);
  const session = await api.fetch(request({path:'/api/session'}), env);
  assert.deepEqual(await session.json(), {configured:true,default_model:DEFAULT_MODEL});
  await expectError(await api.fetch(request(), {}),503,'not_configured');
  await expectError(await api.fetch(request({token:'wrong'}),env),401,'unauthorized');
  await expectError(await api.fetch(request({token:null}),env),401,'unauthorized');
  await expectError(await api.fetch(request({origin:'https://other.example'}),env),403,'origin_not_allowed');
});

test('CORS preflight permits the TimeMemo client without requiring a model call', async () => {
  const res = await createService().fetch(new Request('https://service.example/api/extract',{method:'OPTIONS',headers:{Origin:'https://timememo.net'}}),env);
  assert.equal(res.status,204); assert.equal(res.headers.get('Access-Control-Allow-Origin'),'https://timememo.net');
  assert.match(res.headers.get('Access-Control-Allow-Headers'),/Authorization/);
});

test('image and native PDF requests carry fixed extraction schema, spending bounds and provenance', async () => {
  for (const [bytes,type] of [[png,'image/png'],[pdf,'application/pdf']]) {
    let sent;
    const api = createService({fetcher: async (url,options) => { assert.equal(url,'https://openrouter.ai/api/v1/chat/completions'); sent = JSON.parse(options.body); return upstream(); }});
    const res = await api.fetch(request({bytes,type}),env);
    assert.equal(res.status,200); const data = await res.json();
    assert.equal(data.model,DEFAULT_MODEL); assert.equal(data.request_id,'test-request');
    assert.equal(data.usage.reasoning_tokens,20); assert.equal(data.usage.cost,.0007);
    assert.equal(res.headers.get('Cache-Control'),'no-store');
    assert.deepEqual(sent.provider.max_price,{prompt:.25,completion:1.5});
    assert.equal(sent.provider.data_collection,'deny'); assert.equal(sent.response_format.json_schema.strict,true);
    assert.equal(sent.max_tokens,3072); assert.equal(sent.reasoning.effort,'minimal');
    assert.equal(sent.messages[1].content[1].type,type === 'application/pdf' ? 'file' : 'image_url');
    if(type === 'application/pdf') assert.equal(sent.plugins[0].pdf.engine,'native');
  }
});

test('invalid file types, excessive sizes and inherited model names fail before billing', async () => {
  let calls = 0; const api = createService({fetcher: async () => {calls++; return upstream();}});
  await expectError(await api.fetch(request({bytes:new TextEncoder().encode('not png')}),env),415,'unsupported_file');
  await expectError(await api.fetch(request({type:'text/plain'}),env),415,'unsupported_file');
  await expectError(await api.fetch(request({bytes:new Uint8Array(MAX_FILE_BYTES+1)}),env),413,'file_too_large');
  await expectError(await api.fetch(request({headers:{'Content-Length':String(MAX_FILE_BYTES+200000)}}),env),413,'file_too_large');
  for(const model of ['toString','constructor','__proto__','random/model']) {
    await expectError(await api.fetch(request({model}),env),400,'model_unavailable');
    assert.throws(() => buildModelRequest({type:'image/png'},png,model));
  }
  assert.equal(calls,0);
});

test('strict schema rejects missing envelopes, invented fields and invalid evidence page numbers', () => {
  assert.equal(matchesSchema(result()),true);
  assert.equal(matchesSchema({status:'readable'}),false);
  assert.equal(matchesSchema({...result(),account:{id:'forged'}}),false);
  for(const page of [0,1.2,1001,'1',null]) assert.equal(matchesSchema(result({evidence:[{field:'service.summary',page,quote:'Repair'}]})),false);
  assert.equal(matchesSchema(result({evidence:[{field:'service.summary',page:1,quote:'Repair'}]})),true);
});

test('provider schema keeps fields, nulls and enums while local validation retains unsupported bounds', () => {
  const portable=providerSchema();
  assert.deepEqual(portable.required,AI_EXTRACTION_SCHEMA.required);
  assert.equal(portable.additionalProperties,false);
  assert.deepEqual(portable.properties.amount.properties.total.type,['number','null']);
  assert.deepEqual(portable.properties.status.enum,AI_EXTRACTION_SCHEMA.properties.status.enum);
  assert.equal(portable.properties.evidence.maxItems,undefined);
  assert.equal(portable.properties.property.properties.service_address.maxLength,undefined);
  const oversized=result(); oversized.property.service_address='x'.repeat(601);
  assert.equal(matchesSchema(oversized),false);
  assert.equal(AI_EXTRACTION_SCHEMA.properties.evidence.maxItems,300);
});

test('malformed, truncated, oversize and incomplete upstream replies fail without becoming receipt drafts', async () => {
  const replies = [
    () => upstream({status:'readable'}),
    () => upstream(result(),{choices:[{finish_reason:'length',message:{content:'{}'}}]}),
    () => new Response('not JSON'),
    () => new Response('x'.repeat(512*1024+1)),
    () => upstream(result(),{choices:[{finish_reason:'stop',message:{content:'```json\n{}\n```'}}]}),
  ];
  for(const response of replies) await expectError(await createService({fetcher:async()=>response()}).fetch(request(),env),502,'invalid_response');
});

test('upstream failures map to actionable codes without exposing its message or key', async () => {
  for(const [upstreamStatus,status,code] of [[402,402,'insufficient_credits'],[429,429,'rate_limited'],[401,503,'service_auth_failed'],[403,503,'service_auth_failed'],[404,503,'model_unavailable'],[500,502,'upstream_failed']]) {
    const api=createService({fetcher:async()=>Response.json({error:{code:upstreamStatus,message:env.OPENROUTER_API_KEY}},{status:upstreamStatus})});
    await expectError(await api.fetch(request(),env),status,code);
  }
});

test('model timeout releases concurrency and returns timeout', async () => {
  let shouldStall=true;
  const api=createService({timeoutMs:20,fetcher:async(_url,{signal})=> shouldStall ? new Promise((_resolve,reject)=>signal.addEventListener('abort',()=>reject(Error('aborted')),{once:true})) : upstream()});
  await expectError(await api.fetch(request(),env),504,'timeout');
  shouldStall=false; assert.equal((await api.fetch(request(),env)).status,200);
});

test('stalled uploads cancel promptly, release both slots, and do not charge', async () => {
  let calls=0,cancelled=0;
  const api=createService({timeoutMs:25,fetcher:async()=>{calls++;return upstream();}});
  const makeStall=()=>new Request('https://service.example/api/extract',{method:'POST',duplex:'half',headers:{Authorization:`Bearer ${env.DOMIC_PILOT_TOKEN}`,'Content-Type':'multipart/form-data; boundary=test'},body:new ReadableStream({cancel(){cancelled++;}})});
  const results=await Promise.all([api.fetch(makeStall(),env),api.fetch(makeStall(),env)]);
  for(const response of results) await expectError(response,504,'timeout');
  assert.equal(calls,0); assert.equal(cancelled,2);
  assert.equal((await api.fetch(request(),env)).status,200); assert.equal(calls,1);
});

test('soft per-isolate rate limit refuses the thirteenth paid call and expires', async () => {
  let clock=0,calls=0;
  const api=createService({now:()=>clock,fetcher:async()=>{calls++;return upstream();}});
  for(let i=0;i<12;i++) assert.equal((await api.fetch(request(),env)).status,200);
  await expectError(await api.fetch(request(),env),429,'rate_limited'); assert.equal(calls,12);
  clock=60001; assert.equal((await api.fetch(request(),env)).status,200); assert.equal(calls,13);
});

test('bounded streaming reader rejects overflow and pre-aborted reads', async () => {
  await assert.rejects(readBounded(new Blob(['abcd']).stream(),3),{code:'file_too_large'});
  const controller=new AbortController();controller.abort();
  let cancelled=false;
  await assert.rejects(readBounded(new ReadableStream({cancel(){cancelled=true;}}),3,controller.signal),{code:'timeout'});
  assert.equal(cancelled,true);
  const neverCancels=new ReadableStream({start(c){c.enqueue(new Uint8Array(10));},cancel(){return new Promise(()=>{});}});
  await assert.rejects(readBounded(neverCancels,3),{code:'file_too_large'});
});

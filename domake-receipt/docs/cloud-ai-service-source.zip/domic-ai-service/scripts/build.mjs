import { mkdir, copyFile, readdir, readFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
await mkdir('dist/server/shared', { recursive: true });
await mkdir('dist/.openai', { recursive: true });
execFileSync(process.execPath, ['--check', 'worker.js']);
await copyFile('worker.js', 'dist/server/index.js');
for (const name of await readdir('shared')) {
  if (name.endsWith('.js')) { execFileSync(process.execPath, ['--check', `shared/${name}`]); await copyFile(`shared/${name}`, `dist/server/shared/${name}`); }
}
const config = JSON.parse(await readFile('.openai/hosting.json', 'utf8'));
if (!config.project_id) throw Error('Register the Site before building');
await copyFile('.openai/hosting.json', 'dist/.openai/hosting.json');
console.log('Worker built. Runtime credentials are not bundled.');

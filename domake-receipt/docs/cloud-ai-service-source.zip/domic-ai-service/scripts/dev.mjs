import http from 'node:http';
import { Readable } from 'node:stream';
import service from '../worker.js';
const port = Number(process.env.PORT || 8789);
http.createServer(async (req, res) => {
  try {
    const request = new Request(`http://localhost:${port}${req.url}`, { method: req.method, headers: req.headers, ...(['GET','HEAD'].includes(req.method) ? {} : { body: Readable.toWeb(req), duplex: 'half' }) });
    const result = await service.fetch(request, process.env);
    res.writeHead(result.status, Object.fromEntries(result.headers));
    res.end(Buffer.from(await result.arrayBuffer()));
  } catch { res.writeHead(500); res.end('{"error":{"code":"upstream_failed"}}'); }
}).listen(port, '127.0.0.1', () => console.log(`Local: http://localhost:${port}`));

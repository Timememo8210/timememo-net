Source snapshot for Domic Home Passport, 12 September 2026.

Runtime source matches the live service acceptance run. README reflects the completed pilot.

This archive intentionally excludes Git internals, hosting registration metadata, build outputs, real environment files and all secrets. Node 22+ can run npm test. For deployment, register/configure your hosting project and provide its .openai/hosting.json before using the Sites build script, or adapt worker.js to a compatible Worker host. Existing production deployment is maintained separately; do not overwrite its credentials with this example.

Frontend and stored-record schema: https://github.com/Timememo8210/timememo-net/tree/main/domake-receipt
Live report: https://timememo.net/domake-receipt/ai-pilot/

# Domic Home Passport AI service

Cloudflare Workers-compatible extraction API for the existing TimeMemo receipt website. It runs in cloud hosting and does not require the owner's Mac to stay awake. The frontend remains in `timememo-net/domake-receipt` on GitHub Pages.

## Current verification — 12 September 2026

The service is deployed at `https://domic-home-passport-ai.bobomail2000.chatgpt.site`, with server-side OpenRouter and pilot-code secrets configured. Its default model is `google/gemini-3.1-flash-lite`. Health returns `configured: true`; unauthenticated extraction is rejected. The English TimeMemo website successfully uploaded a real fictional PDF through this API, presented an editable draft, required explicit confirmation, and preserved the edited record after reload.

The frontend's `AI_ENDPOINT` now points to this service. The service URL is public so the existing GitHub Pages website can call it; extraction is protected by the independent pilot access code and an allowed-origin check. Public reachability is not public anonymous model access. The bilingual live test report is at `https://timememo.net/domake-receipt/ai-pilot/`.

## Contract and flow

1. The user selects their property and uploads one JPEG, PNG, WebP or PDF (up to 6 MiB).
2. A pilot access code is checked by `/api/session`. This does not call a model. The browser retains only this code in session storage; OpenRouter credentials stay server-side.
3. `/api/extract` validates the file and sends its content to OpenRouter using a fixed prompt and strict JSON schema. Native PDF input avoids an additional OCR parser service.
4. A valid response contains `extraction`, `model`, `request_id`, `usage`, and `elapsed_ms`. Classification distinguishes readable, partial, unreadable and unrelated content. Missing facts are null; categorical unknowns use `unknown`; absent lists are empty.
5. The frontend normalizes a draft, preserving separately the service company, actual worker, service address/date, document date, work details and total. Supporting quotations are model-supplied, not independently verified OCR.
6. Users edit the draft and explicitly confirm it before saving. Model output cannot assign an account, property UID, file hash or confirmation state. Original file and record are saved in the existing browser IndexedDB; **this API does not implement a shared customer database**.

The authoritative extraction schema and prompt are in `shared/ai-contract.js`. The stored-record schema lives in the frontend's `docs/receipt.schema.json`.

## Configuration

Set runtime environment variables through Sites, never in a public source file:

| Variable | Purpose |
|---|---|
| `OPENROUTER_API_KEY` | Dedicated secret API key; apply a small total spending cap in OpenRouter for the pilot |
| `DOMIC_PILOT_TOKEN` | Independent random secret, at least 24 characters; shared pilot access only |
| `DOMIC_MODEL` | Default `google/gemini-3.1-flash-lite` |
| `DOMIC_ALLOWED_ORIGINS` | Defaults to `https://timememo.net`; comma-separated exact origins |

Changing runtime variables requires a new deployment of the saved version. Do not place API keys or pilot codes in Git, exported records, screenshots or public reports. The shared pilot code is not production user authentication. Before a broad customer launch add individual authentication, durable per-user quotas and the shared records/attachment database.

## Cost and reliability controls

- Fixed endpoint and extraction prompt; allowlisted model IDs; no arbitrary URLs or general chat proxy.
- Standard-rate provider price ceilings, Flex providers excluded for interactive use, minimal/low reasoning, 3,072 completion-token ceiling, no application-level retries or automatic model upgrades.
- 35-second deadline covering upload and upstream inference. The browser allows 45 seconds for network overhead.
- Two concurrent calls and 12 calls/minute **per Worker isolate** are soft safeguards, not a global quota. The supplied OpenRouter key was verified with a $10 spending cap at the end of the 12 September test run. Account credit is separate from this key cap. Add durable per-user quotas before broader distribution.
- Request/form and response sizes are bounded. Documents are not persisted or logged by this service. Requests ask OpenRouter to route to providers denying data collection; provider retention terms still govern processing.
- Transport failures return short actionable codes and cannot silently turn into successful blank receipts.
- Usage reports include billed token counts, reasoning tokens when returned, and actual response cost when returned. Never infer measured cost from list prices alone.

## Validation and build

Node.js 22 or later; no runtime dependencies. `npm test` runs deterministic request/response, auth, CORS, schema, size, error, timeout and rate-limit tests using a mock upstream. `npm run build` emits `dist/server/index.js`, shared modules and the registered hosting manifest. `npm run dev` exposes a local development adapter on port 8789; local testing requires explicit runtime variables and allowed origin settings.

## Live acceptance and remaining limits

Live experiments compared 2.5, 3.1 and 3.5 Flash Lite on the same three fictional originals and compared 3.1 with 3.8 Flash on one simulated phone photo. These are small samples, not general accuracy or latency guarantees. The deployed API has also accepted a PDF and rejected an unrelated restaurant receipt; browser interaction evidence is recorded in the linked report. One incomplete electrician slip still shortens the company name, requiring manual correction. Unknown fields stay unknown. A Gemini provider-schema incompatibility found during live testing was fixed by simplifying the transport schema while retaining full local validation. The frontend has 85 deterministic checks and this service has 12; those are separate from live model tests.
